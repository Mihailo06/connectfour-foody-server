/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.connectfourserver;

public class ConnectFour extends Game implements GameLog
{
    int ComputerMoveXPosition; // comp remembers a x pos
    int ComputerMoveYPosition; // comp remembers a y pos
    public ConnectFour(int _gameId, String game, Player player1, Player player2, int[][] Field)
    {
        // minXFelder = 4; // minimum for x
        // minYFelder = 4; // minimum for y
        pickedGame = game;
        this.player1 = player1;
        this.player2 = player2;
        GameBoardCoordinates = Field;
        MoveCounter = 0;
        gameId = _gameId;
        columns = GameBoardCoordinates.length;
        rows = GameBoardCoordinates[0].length;

        board = new Board(rows, columns);
        GameBoardCoordinates = Field;
        GameIsOver = false;
        winner = 0;
        for(int i = 0; i < columns ; i++)
        {
            for(int j= 0; j < rows; j++)
            {
                GameBoardCoordinates[i][j] = 0;
            }
        }
    } 

    @Override
    public void move(Player _currentPlayer, int x, int y)
    {
        System.out.println("move " + _currentPlayer.playerName + " " + x + " " + y + _currentPlayer.isHuman + " " + rows);
        currentPlayer = _currentPlayer.playerIndex;
        boolean moveIsOver = false;
        int pos = 0; // position x of the move
        boolean played = false; // true : move was successfully played
        
            if(_currentPlayer.isHuman)
            {   
                pos = x;
                for(int i = rows - 1; i > -1; i--)
                {
                    System.out.print(i + "a");
                    if(GameBoardCoordinates[pos-1][i]== 0)
                    {
                        System.out.println();
                        System.out.println(GameBoardCoordinates[pos-1][i] + " a" + _currentPlayer.playerIndex);
                        GameBoardCoordinates[pos-1][i] = _currentPlayer.playerIndex;
                        played = true;

                        // check for if the player won
                        if(checkHorizontal(pos-1, i, _currentPlayer.playerIndex, true) >=4 || checkVertical(pos-1, i, _currentPlayer.playerIndex, true) >=4 || checkLeftStroke(pos-1, i, _currentPlayer.playerIndex, true) >=4 || checkRightStroke(pos-1, i, _currentPlayer.playerIndex, true) >=4)
                        {
                            System.out.println("player" + _currentPlayer + " won.");
                            winner = _currentPlayer.playerIndex;
                            GameIsOver = true;
                            newMove(pos, i, _currentPlayer); // add move to the list
                            return;
                        }
                    
                         board.UpdateBoard(GameBoardCoordinates);
                        newMove(pos, i, _currentPlayer); // add move to the list
                        break;
                    }
            
                }
            }
            else
            {

                //random x || last x...
                if(moveList.size()>2) //if it's the first move
                {
                
                    if (ComputerMoveXPosition == 0) //if comp doesn't remember a move then remember your last move
                    {
                        ComputerMoveXPosition = moveList.get(moveList.size() - 2).x() - 1;
                        ComputerMoveYPosition = moveList.get(moveList.size() - 2).y();
                    }

                    int[] a,b,c,d; //arrays which return from check...
                    int[] e,f,g,h; //arrays from check... for the enemy's last move
                    int otherPlayerIndex;
                    if(_currentPlayer.playerIndex == 1)
                    {
                        otherPlayerIndex = 2;
                    }
                    else 
                    {
                         otherPlayerIndex = 1;
                    }
                    

                    // array[0] == X pos
                    // array[1] == number of moves in a line e.g. [1001] => array[1] = 2
                    a = checkHorizontalArray(ComputerMoveXPosition, ComputerMoveYPosition, _currentPlayer.playerIndex);
                    b= checkVerticalArray(ComputerMoveXPosition, ComputerMoveYPosition, _currentPlayer.playerIndex);
                    c = checkLeftStrokeArray(ComputerMoveXPosition, ComputerMoveYPosition, _currentPlayer.playerIndex);
                    d = checkRightStrokeArray(ComputerMoveXPosition, ComputerMoveYPosition, _currentPlayer.playerIndex);
                    
                    e = checkHorizontalArray(moveList.get(moveList.size()-1).x() -1, moveList.get(moveList.size()-1).y(), otherPlayerIndex);
                    f = checkVerticalArray(moveList.get(moveList.size()-1).x()-1, moveList.get(moveList.size()-1).y(), otherPlayerIndex);
                    g = checkLeftStrokeArray(moveList.get(moveList.size()-1).x()-1, moveList.get(moveList.size()-1).y(), otherPlayerIndex);
                    h = checkRightStrokeArray(moveList.get(moveList.size()-1).x()-1, moveList.get(moveList.size()-1).y(), otherPlayerIndex);

                    
                    
                    int[] max = new int[2]; // pick the best check
                    max[0] = a[0];
                    max[1] = a[1];
                    
                    if(b[1] > max[1])
                    {max = b;}
                    
                    if(c[1] > max[1])
                    {max = c;}
                    
                    if(d[1] > max[1])
                    {max = d;}
                    

                    // if 1 (4-3) or 2 (4-2) moves are missing to win: play those moves
                    if(max[1] == 3 )
                    {
                        pos = max[0];
                    }
                    else if(max[1] == 2)
                    {
                        pos = max[0];
                        ComputerMoveXPosition = max[0];

                    }
                    else if(max[1] == 1)
                    {
                        pos = max[0];
                        // ComputerMoveXPosition = 0;
                        //ComputerMoveYPosition = 0;
                    }
                    if(max[1] == -1)
                    {
                        //ComputerMoveXPosition = 0;
                        //ComputerMoveYPosition =0;
                        pos= (int)(Math.random() * rows) + 1;
                    }

                    if(e[1] >= 3)
                    {
                        pos = e[0];
                    }
                    else if (f[1] >= 3)
                    {
                        pos = f[0];
                       
                    }
                    else if(g[1] >= 3)
                    {
                        pos = g[0];
                       
                    }
                    else if (h[1] >=3)
                    {
                        pos = h[0];
                        
                    }
                    
                    System.out.println( " computer plays the move x = " + (pos+1));
                    pos++;
                    if(pos >=GameBoardCoordinates.length + 1)
                    {
                        pos = GameBoardCoordinates.length;
                    }
                }
                else
                {
                    pos= (int)(Math.random() * rows) + 1; //if its the 1st move
                }
                    
                for(int i = rows- 1; i >= 0; i--)
                {
                    if(GameBoardCoordinates[pos-1][i]== 0)
                    {
                        GameBoardCoordinates[pos-1][i] = _currentPlayer.playerIndex;
                        played = true;
                        if(checkHorizontal(pos-1, i, _currentPlayer.playerIndex, true) >=4 || checkVertical(pos-1, i, _currentPlayer.playerIndex, true) >=4 || checkLeftStroke(pos-1, i, _currentPlayer.playerIndex, true) >=4 || checkRightStroke(pos-1, i, _currentPlayer.playerIndex, true) >=4)
                        {
                            //comp won
                            System.out.println("Player " + _currentPlayer + " won.");
                            GameIsOver= true;
                            winner = _currentPlayer.playerIndex;
                            newMove(pos, i, _currentPlayer);
                            return;
                        }
                        board.UpdateBoard(GameBoardCoordinates);
                        newMove(pos , i, _currentPlayer);
                        break;
                    }
            
                }
            }   
        
        
            boolean emptySlot = true; // true: theres still empty slots
            for(int i = 0; i<columns; i++)
            {
                
                    if(GameBoardCoordinates[i][0] == 0)
                    {
                        emptySlot = true;
                        break;               
                    }
                    else
                    {
                        emptySlot = false;
                    }
                
                if(emptySlot == true)
                {
                    break;
                }
            }
            if(emptySlot != true)
            {
                GameIsOver = true;
                System.out.println("All slots are occupied, game over!");
                System.out.println();
                return;
            }
    }


    public void removeLastMove() // abstract method from log
    {
        GameBoardCoordinates[moveList.get(moveList.size() -1).x() - 1][moveList.get(moveList.size() -1).y() ] = 0;
        moveList.remove(moveList.size() -1);

    }

    public void newMove(int x, int y, Player player) // abstract method from log
    {
        Move move = new Move(player.playerIndex, MoveCounter, x, y );
        moveList.add(move);
        MoveCounter++;
        System.out.println("new move : + size:" + moveList.size() + " " + x + " " + y);
    }

    //check if there's 4 slots in a line for the player 
    private int checkHorizontal(int xPos, int yPos, int playerIndex, boolean picked)
    {
        int win = 0;
        if(picked) //if picked != true : comp searches for a slot to play his move in
        {
            win = 1;
        }
        for(int i = 1; i <xPos ; i++)
        {
            if (GameBoardCoordinates[xPos - i][yPos] == playerIndex)
            {
                win++;
            }
            else
            {
                break;
            }
        }
        for(int i = 1; i < (GameBoardCoordinates.length - xPos ); i++)
        {
            if(GameBoardCoordinates[xPos + i][yPos] == playerIndex)
            {
                win++;
            }
            else
            {break;}
        }

        
        return win;
        

    }

    // check for computer to see analyze a horizontal line
    private int[] checkHorizontalArray(int xPos, int yPos, int playerIndex)
    {
        
        int[] arrayData = new int[2]; // arrayData[1] : how many indexes are there in a line, arrayData[0] : xPos
        int left = 0; // empty spaces to the left of xPos
        int right = 0; // empty spaces to the right of xPos
        
        for(int i = 1; i <Math.min(xPos,4) ; i++)
        {
            if (GameBoardCoordinates[xPos - i][yPos] == playerIndex || GameBoardCoordinates[xPos-i][yPos] == 0)
            {
                left++;
            }
            else
            {
                break;
            }
        }
        
        for(int i = 1; i < Math.min((GameBoardCoordinates.length - xPos ),4); i++)
        {
            if(GameBoardCoordinates[xPos + i][yPos] == playerIndex || GameBoardCoordinates[xPos + i][yPos] == 0)
            {
                right++;
            }
            else
            {break;}
        }
       
        

        if (left + right + 1 <4)
        {
        arrayData[0] = -1; // not enough empty spaces in this line to be able to win
        arrayData[1] = -1;
        
        return(arrayData);
        }
       
        if(right> 3)
        {
            right =3; // you only need 3 more empty ones to get the 4 in a row 
        }
        if(left > 3)
        {
            left =3; //you only need 3 more empty ones to get the 4 in a row 
        }

        
        int _left = 0; // count of playerIndexes
        for(int i = 1; i< left + 1; i++)
        {
            if (GameBoardCoordinates[xPos - i][yPos] == playerIndex)
            {
                _left++;
                
            }
            
        }

        int _right = 0; // count of playerIndexes
        for(int i = 1; i < _right + 1; i++)
        {
            if(GameBoardCoordinates[xPos + i][yPos] == playerIndex)
            {
                _right++;
               
            }
        }

        
        if(_right== 2 && right <= 3)
        {
            if(right==3) // if 2/3rds right have the playerindex
            {
                for(int i = 1; i < 4; i++)
                {
                    if(GameBoardCoordinates[xPos+i][yPos] == 0)
                    {
                        arrayData[0] = xPos + i;
                        arrayData[1] = 3;
                        
                        return arrayData; 
                    }
                }
            }
            else // else there's 2/2 indexes on the right
            {
                arrayData[0] = xPos - 1;
                arrayData[1] = 3;
                
                return arrayData;

            }
        }
        if(_left== 2 && left <= 3)
        {
            if(left==3)//if 2/3 indexes on the left
            {
                for(int i = 1; i < 4; i++)
                {
                    if(GameBoardCoordinates[xPos-i][yPos] == 0)
                    {
                        arrayData[0] = xPos - i;
                        arrayData[1] = 3;
                       
                        return arrayData; 
                    }
                }
            }
            else //else 2/2 indexes on the left
            {
                arrayData[0] = xPos + 1;
                arrayData[1] = 3;
              
                return arrayData;

            }
        }

        if(_left==1 && left <= 3)
        {
            for( int i = 1; i < left+ 1; i++)
            {
                if(GameBoardCoordinates[xPos -i][yPos] == 0)
                {
                    arrayData[0] = xPos - i;
                    arrayData[1] = 2;
                
                    return arrayData;
                }

            }
        }

        if(_right==1 && right <= 3)
        {
            for( int i = 1; i < right + 1; i++)
            {
                if(GameBoardCoordinates[xPos +i][yPos] == 0)
                {
                    arrayData[0] = xPos + i;
                    arrayData[1] = 2;
                   
                    return arrayData;
                }

            }
        }

        
        if(left > 0)
        {
            if(right > 0)
            {
                if((int)Math.random() == 1)
                {
                    arrayData[0] = xPos + 1;
                }
                else
                {
                    arrayData[0] = xPos-1;
                }
            }
            else{arrayData[0] = xPos-1;}
            
        }
        else
        {
            if(right >0)
            {arrayData[0] = xPos+1;}
            
        }
        arrayData[1] = 1;

        
       
        return arrayData;
    }

    //if there's 4 empty vertical slots for the player
    private int checkVertical(int xPos, int yPos, int playerIndex, boolean picked)
    {
        int win = 0;
        if(picked) 
        {
            win = 1;
        }
        
        for(int i = 1; i < (GameBoardCoordinates[0].length - yPos ); i++)
        {
            if(GameBoardCoordinates[xPos ][yPos + i] == playerIndex)
            {
                win++;
            }
            else
            {break;}
        }

        return win;
    }

    // check for computer to see analyze a horizontal line
    private int[] checkVerticalArray(int xPos, int yPos, int playerIndex)
    {
        int[] arrayData = new int[2]; // arrayData[0] : xPos , arrayData[1] : count of playerIndexes in a line
        int top = 0; 
        int bot = 0;
        for(int i = 1; i <Math.min(yPos,4) ; i++)
        {
            if (GameBoardCoordinates[xPos][yPos - i ] == playerIndex || GameBoardCoordinates[xPos][yPos-i ] == 0)
            {
                top++;
            }
            else
            {
                break;
            }
        }
        for(int i = 1; i < Math.min((GameBoardCoordinates[0].length - yPos ),4); i++)
        {
            if(GameBoardCoordinates[xPos][yPos+ i] == playerIndex || GameBoardCoordinates[xPos][yPos + i] == 0)
            {
                bot++;
            }
            else
            {break;}
        }

        if (top+ bot + 1 <4)
        {
        arrayData[0] = -1; // not enough empty slots
        arrayData[1] = -1;
      
        return(arrayData);
        }
        if(top > 3)
        {
            top =3; 
        }
        if(bot > 3)
        {
            bot = 3; 
        }

        
        int _bot = 0; // count of indexes to the right of x
        for(int i = 1; i < bot + 1; i++)
        {
            if(GameBoardCoordinates[xPos][yPos + 1] == playerIndex)
            {
                _bot++;
            }
            else {break;}
        }


        if (top>= 1)
        {
            if(GameBoardCoordinates[xPos][yPos-1] != 0 && GameBoardCoordinates[xPos][yPos=1] != playerIndex)
            {
                arrayData[0] = xPos;
                arrayData[1] = 1;
            }
        }

        if(top >= 1)
        {
        int otherIndex;
        if(playerIndex == 1)
        {
        otherIndex = 2;
        }
        else 
        {
        otherIndex = 1;
        }
        if(GameBoardCoordinates[xPos][yPos-1] == otherIndex )// if its already occupied
        {
        arrayData[0] = xPos;
        arrayData[1] = -1;
        
        return arrayData;
        }
        }
        arrayData[0] = xPos;
        arrayData[1] = _bot+1;

        
     
        return arrayData;
    }

    //check if there's 4 in a row in a diagonal (bot left -> top right)
    private int checkLeftStroke(int xPos, int yPos, int playerIndex, boolean picked)
    {
        int win= 0;
        if(picked) //if picked : comp looks where to play move
        {
            win = 1;
        }

        int botLeft = Math.min(xPos , GameBoardCoordinates[0].length - yPos ) - 1;
        int topRight = Math.min(GameBoardCoordinates.length - xPos, yPos) - 1;
        for(int i = topRight ; i > 0 ; i--)
        {
            if(topRight <=0)
            {
                break;
            }
            if (GameBoardCoordinates[xPos +i][yPos-i] == playerIndex)
            {
                win++;
            }
            else
            {
                break;
            }
        }
        for(int i = botLeft; i > 0; i--)
        {
            if(botLeft <=0)
            {
                break;
            }
            if(GameBoardCoordinates[xPos -i ][yPos + i] == playerIndex)
            {
                win++;
            }
            else
            {break;}
        }

        return win;
    }

    // method for comp to analyze the diagonal
    private int[] checkLeftStrokeArray(int xPos, int yPos, int playerIndex)
    {
        int[] arrayData = new int[2]; // arrayData[0] : xPos , arrayData[1] : how many in a row
        int left = 0; 
        int right = 0;
        int botLeft = Math.min(xPos , GameBoardCoordinates[0].length - yPos ) - 1;
        int topRight = Math.min(GameBoardCoordinates.length - xPos, yPos) - 1;
        for(int i = Math.min( topRight,3) ; i > 0 ; i--)
        {
            if(topRight <=0)
            {
                break;
            }
            if (GameBoardCoordinates[xPos +i][yPos-i] == playerIndex || GameBoardCoordinates[xPos +i][yPos -i] == 0)
            {
                right++;
            }
            else
            {
                break;
            }
        }
        for(int i = Math.min( botLeft,3) ; i > 0 ; i--)
        {
            if(botLeft <=0)
            {
                break;
            }
            if(GameBoardCoordinates[xPos -i ][yPos + i] == playerIndex || GameBoardCoordinates[xPos-i][yPos+i] == 0)
            {
                left++;
            }
            else
            {
                break;
            }
        }
        

        if (left + right + 1 <4)
        {
            arrayData[0] = -1; // not enough spaces
            arrayData[1] = -1;
       
            return(arrayData);
        }
        if(right> 3)
        {
            right =3; 
        }
        if(left > 3)
        {
            left = 3; 
        }

        int _left = 0;
        for(int i = 1; i< left + 1; i++)
        {
            if (GameBoardCoordinates[xPos - i][yPos +i] == playerIndex)
            {
                _left++;
            }
            
        }

        if(_left== 2 && left <= 3)
        {
            if(left==3)//if 2/3 left have indexes
            {
                for(int i = 1; i < 4; i++)
                {
                    if(GameBoardCoordinates[xPos-i][yPos+i] == 0)
                    {
                        arrayData[0] = xPos - i;
                        arrayData[1] = 3;
                      
                        return arrayData; 
                    }
                }
            }
            else //else 2/2 left -> gotta play 1 move on the right
            {
                arrayData[0] = xPos - 1;
                arrayData[1] = 3;
          
                return arrayData;

            }
        }

        if(_left==1 && left <= 3)
        {
            if(left ==3)
            {
                if( GameBoardCoordinates[xPos-3][yPos+3]==0)
                {
                    arrayData[0] = xPos-3;
                    arrayData[1] = 2;
                  
                    return arrayData;
                }
            }
            
                if(yPos+2 < GameBoardCoordinates.length)
                {
                    if(GameBoardCoordinates[xPos-1][yPos+2] != 0)
                    {
                        arrayData[0] = xPos -1;
                        arrayData[1] = 2;
              
                        return arrayData;
                    }
                }
            
            if(left ==2)
            {
                if(yPos+3 < GameBoardCoordinates.length)
                {
                    if(GameBoardCoordinates[xPos-2][yPos+3] != 0)
                    {
                        arrayData[0] = xPos -2;
                        arrayData[1] = 2;
                 
                        return arrayData;
                    }
                }
            }
            
        }
        int _right = 0; // count playerindexes to the right
        for(int i = 1; i < _right + 1; i++)
        {
            if(GameBoardCoordinates[xPos + i][yPos-i] == playerIndex)
            {
                _right++;
            }
        }
        


        if(_right== 2 && right <= 3)
        {
            if(right==3)//if 2/3 right are indexes
            {
                for(int i = 1; i < 4; i++)
                {
                    if(GameBoardCoordinates[xPos+i][yPos-i] == 0)
                    {
                        arrayData[0] = xPos + i;
                        arrayData[1] = 3;
              
                        return arrayData; 
                    }
                }
            }
            else //else 2/2 right are indexes
            {
                arrayData[0] = xPos + 1;
                arrayData[1] = 3;
      
                return arrayData;

            }
        }

        if(_right==1 && right <= 3)
        {
            if(right ==3)
            {
                if( GameBoardCoordinates[xPos+3][yPos-3]==0)
                {
                    arrayData[0] = xPos+3;
                    arrayData[1] = 2;
                 
                    return arrayData;
                }
            }
            
                if(yPos-2 >= 0)
                {
                    if(GameBoardCoordinates[xPos+1][yPos-2] != 0)
                    {
                        arrayData[0] = xPos +1;
                        arrayData[1] = 2;
                        
                        return arrayData;
                    }
                }
            
            if(right ==2)
            {
                if(yPos-3 >= 0)
                {
                    if(GameBoardCoordinates[xPos+2][yPos-3] != 0)
                    {
                        arrayData[0] = xPos +2;
                        arrayData[1] = 2;
                       
                        return arrayData;
                    }
                }
            }

            
        }

        arrayData[0] = -1;
        arrayData[1] = -1;

        
       
        return arrayData;
    }

    //if the player has 4 in a row in a diagonal
    private int checkRightStroke(int xPos, int yPos, int playerIndex, boolean picked)
    {
        int win = 0;
        if(picked) //if picked !+ true : comp decides where to play move
        {
            win = 1;
        }
        int botRight = Math.min(GameBoardCoordinates.length - xPos , GameBoardCoordinates[0].length - yPos ) - 1;
        int topLeft = Math.min(xPos, yPos) - 1;
        for(int i = topLeft ; i > 0 ; i--)
        {
            if(topLeft <=0)
            {
                break;
            }
            if (GameBoardCoordinates[xPos -i][yPos-i] == playerIndex)
            {
                win++;
            }
            else
            {
                break;
            }
        }
        for(int i = botRight; i > 0; i--)
        {
            if(botRight <=0)
            {
                break;
            }
            if(GameBoardCoordinates[xPos +i ][yPos + i] == playerIndex)
            {
                win++;
            }
            else
            {break;}
        }
        return win;
    }

    // method for comp to analyze diagonal line
    private int[] checkRightStrokeArray(int xPos, int yPos, int playerIndex)
    {
        int[] arrayData = new int[2]; // arrayData[0] : xPos, arrayData[1] : count of indexes in a line
        int left = 0; 
        int right = 0;
        int botRight = Math.min(GameBoardCoordinates.length - xPos , GameBoardCoordinates[0].length - yPos ) - 1;
        int topLeft = Math.min(xPos, yPos) - 1;
        for(int i = Math.min( topLeft,3) ; i > 0 ; i--)
        {
            if(topLeft <=0)
            {
                break;
            }
            if (GameBoardCoordinates[xPos -i][yPos-i] == playerIndex || GameBoardCoordinates[xPos -i][yPos -i] == 0)
            {
                left++;
            }
            else
            {
                break;
            }
        }
        for(int i = Math.min( botRight,3) ; i > 0 ; i--)
        {
            if(botRight <=0)
            {
                break;
            }
            if(GameBoardCoordinates[xPos +i ][yPos + i] == playerIndex || GameBoardCoordinates[xPos+i][yPos+i] == 0)
            {
                right++;
            }
            else
            {
                break;
            }
        }
        

        if (left + right + 1 <4)
        {
        arrayData[0] = -1; // not enough empty spaces
        arrayData[1] = -1;
     
        return(arrayData);
        }
        if(right> 3)
        {
            right =3; 
        }
        if(left > 3)
        {
            left = 3; 
        }
         int _left = 0; // count of indexes to the left of xpos
        
         for(int i = 1; i< left + 1; i++)
        {
            if (GameBoardCoordinates[xPos - i][yPos -i] == playerIndex)
            {
                _left++;
            }
            
        }

        if(_left== 2 && left <= 3)
        {
            if(left==3)//if 2/3 indexes
            {
                for(int i = 1; i < 4; i++)
                {
                    if(GameBoardCoordinates[xPos-i][yPos-i] == 0)
                    {
                        arrayData[0] = xPos - i;
                        arrayData[1] = 3;
                     
                        return arrayData; 
                    }
                }
            }
            else //else 2/2 indexes left
            {
                arrayData[0] = xPos - 1;
                arrayData[1] = 3;
            
                return arrayData;

            }
        }

        if(_left==1 && left <= 3)
        {
            if(left ==3)
            {
                if( GameBoardCoordinates[xPos-3][yPos-3]==0)
                {
                    arrayData[0] = xPos-3;
                    arrayData[1] = 2;
                    
                }
            }
            
                if(yPos-2 >= 0)
                {
                    if(GameBoardCoordinates[xPos-1][yPos-2] != 0)
                    {
                        arrayData[0] = xPos -1;
                        arrayData[1] = 2;
                     
                        return arrayData;
                    }
                }
            
            if(left ==2)
            {
                if(yPos-3 >= 0)
                {
                    if(GameBoardCoordinates[xPos-2][yPos-3] != 0)
                    {
                        arrayData[0] = xPos -2;
                        arrayData[1] = 2;
                       
                        return arrayData;
                    }
                }
            }
            
        }
        int _right = 0; //count indexes to the right
        for(int i = 1; i < _right + 1; i++)
        {
            if(GameBoardCoordinates[xPos + i][yPos+i] == playerIndex)
            {
                _right++;
            }
        }
        


        if(_right== 2 && right <= 3)
        {
            if(right==3)//if 2/3 right are index
            {
                for(int i = 1; i < 4; i++)
                {
                    if(GameBoardCoordinates[xPos+i][yPos+i] == 0)
                    {
                        arrayData[0] = xPos + i;
                        arrayData[1] = 3;
                   
                        return arrayData; 
                    }
                }
            }
            else //else 2/2 indexes are right
            {
                arrayData[0] = xPos + 1;
                arrayData[1] = 3;
             
                return arrayData;

            }
        }

        if(_right==1 && right <= 3)
        {
            if(right ==3)
            {
                if( GameBoardCoordinates[xPos+3][yPos+3]==0)
                {
                    arrayData[0] = xPos+3;
                    arrayData[1] = 2;
                
                    return arrayData;
                }
            }
            
                if(yPos+2 < GameBoardCoordinates.length)
                {
                    if(GameBoardCoordinates[xPos+1][yPos+2] != 0)
                    {
                        arrayData[0] = xPos +1;
                        arrayData[1] = 2;
            
                        return arrayData;
                    }
                }
            
            if(right ==2)
            {
                if(yPos+3 < GameBoardCoordinates.length)
                {
                    if(GameBoardCoordinates[xPos+2][yPos+3] != 0)
                    {
                        arrayData[0] = xPos +2;
                        arrayData[1] = 2;
                     
                        return arrayData;
                    }
                }
            }
            
        }

        arrayData[0] = -1;
        arrayData[1] = -1;

        

        return arrayData;
    }

    
}