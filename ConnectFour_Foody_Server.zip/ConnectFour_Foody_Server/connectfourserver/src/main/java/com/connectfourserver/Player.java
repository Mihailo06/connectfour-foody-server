/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.connectfourserver;

public class Player {

    public String playerName;

    //true:  Player is human
    //false: Player is a Computer
    public boolean isHuman;

    // index for a game
    public int playerIndex;

    //Constructor
    public Player(String playerName, boolean isHuman, int playerIndex){
        this.playerName=playerName;
        this.isHuman=isHuman;
        this.playerIndex = playerIndex;
    }

    public String getName()
    {
        return this.playerName;
    }
}
