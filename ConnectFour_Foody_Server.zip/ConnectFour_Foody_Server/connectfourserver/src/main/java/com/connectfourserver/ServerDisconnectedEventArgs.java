/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.connectfourserver;

import java.net.Socket;

public class ServerDisconnectedEventArgs
{
    private final Socket clientSocket;

    public ServerDisconnectedEventArgs(Socket clientSocket)
    {
        this.clientSocket = clientSocket;
    }

    public Socket getSocket()
    {
        return clientSocket;
    }

    public String getClientAddress()
    {
        return clientSocket.getInetAddress().getHostAddress();
    }

    public int getClientPort()
    {
        return clientSocket.getPort();
    }
}
