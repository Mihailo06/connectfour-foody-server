/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.connectfourserver;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;


public class Client implements ActionListener
{

    static Socket socket;
    static BufferedReader in;
    static BufferedReader stdIn;
    static PrintWriter out;

    public record challange(String challanger, String recipient, String game)
    {}
    private List<challange> challanges = new ArrayList<>();
    boolean connect = true;
    String chatLog = "";
    String userList = "Online Users : \n";
    String hostname;
    int port;
    boolean connecting = true;
    Thread send;
    Thread listen;

    
    
    
    public static void main(String args[]) throws IOException
    {
        if(args.length == 0)
        {
            Client client = new Client(null, -1);
        }
        else
        {
            Client client = new Client(args[0], Integer.parseInt(args[1]));
        }
        
    }
    
    public Client(String hostname, int port)
    {
        
        // try{
            ClientGUI();
            System.out.println(hostname + " : " + port);
            
            
            // if(!(hostname != null && port != -1))
            // {
                //     while(true)
            //     {
                
            //         while(this.connect)
            //         {
                //             //
                
                //             System.out.print("");
                //         }
                //         socket = new Socket(this.hostname, this.port);
                //         if(socket != null)
                //         {
                    //             System.out.println("socket not null");
                    //             if(socket.isConnected())
                    //             {
                        //                 System.out.println("connected");
                        //                 frame1.remove(connectionPanel);
                        //                 frame1.revalidate();
                        //                 frame1.repaint();
                        //                 frame1.add(logInRegisterPanel);                
                        //                 logInRegisterPanel.setVisible(true);
                        //                 frame1.revalidate();
                        //                 frame1.repaint();
                        //                 break;
                        //             }
                        //             else{this.connect = true;}
                        //         }
                        //         else
                        //         {this.connect = true;}
                        //     }
                        
                        // }
                        // else
                        // {
                            //     socket = new Socket(hostname, port);
                            // }
                            
                            // System.out.println("Connecting to server at port " );
    
                            // io streams
                            // in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                            // out = new PrintWriter(socket.getOutputStream(), true);
                            // stdIn = new BufferedReader(new InputStreamReader(System.in));
                            
                            // if(this.connect)
            // {
                // while(true)
                // {
                    //     String input = stdIn.readLine().toLowerCase();
                    //     if( "log in".equalsIgnoreCase(input))
                    //     {
                        //         out.println(input); // "log in"
                        //         String message = in.readLine();
                        //         System.out.println(message); // "enter your email"
                        
                        //         while(true)
                        //         {
                            
                        //             input = stdIn.readLine(); // email
                //             out.println(input);
                //             message = in.readLine(); // email addresse -> "valid"/ "invalid"
                //             if("valid".equalsIgnoreCase(message))
                //             {
                    
                //                 while (true)
                //                 { 
                    //                     System.out.println("enter your Password");
                    //                     input = stdIn.readLine();
                    //                     out.println(input);
                    //                     message = in.readLine();
                    //                     if("valid".equalsIgnoreCase(message))
                    //                     {
                        //                         while (true)
                        //                         {
                            //                             System.out.println("do you want to change your password? 'yes'/'no'");
                //                             input = stdIn.readLine();
                //                             if("yes".equalsIgnoreCase(input))
                //                             {
                    //                                 out.println("change");
                    //                                 System.out.println("enter your new password");
                    //                                 input = stdIn.readLine();
                    //                                 System.out.println("Password changed.");
                    //                                 out.println(input);
                    //                             } 
                    //                             else if("no".equalsIgnoreCase(input))
                    //                             {
                        //                                 out.println("chat");
                        //                                 break;
                        //                             }
                        //                             else
                        //                             {
                            //                                 System.out.println("wrong argument. 'yes'/'no'");
                            //                             }
                            
                //                         }
                //                         System.out.println("Connecting. . .");
                //                         break;
                //                     }
                //                     else if("invalid".equalsIgnoreCase(message))
                //                     {
                //                         System.out.println("invalid password!");
                //                     }
                //                 }
                //                 break;
                //             }
                //             else
                //             {
                    //                 System.out.println("couldn't find email '" + input + "'. Please enter a valid Email.");
                    //             }
                    //         }

                    //         break;
                    //     }
                    //     else if( "register".equalsIgnoreCase(input))
                    //     {
                        //         out.println(input); // input == "register"
                        //         String message = in.readLine(); // "enter your email"
                        //         System.out.println(message);
                        //         while(true)
                        //         {
                            //             input = stdIn.readLine(); //email
                            //             out.println(input);
                            //             message = in.readLine();
                            //             if("valid".equalsIgnoreCase(message))
                            //             {
                                //                 String email = input;
                                //                 System.out.println("enter the password from the email you received");
                                //                 while (true)
                                //                 { 
                                    //                     input = stdIn.readLine();
                                    //                     out.println(input);   
                                    //                     message = in.readLine();
                                    //                     if(message.equalsIgnoreCase("valid"))
                                    //                     {
                                        //                         break;
                                        //                     }
                                        //                     else
                                        //                     {
                                            //                         System.out.println("Invalid password, try again!");
                                            //                     }
                                            //                 }
                                            //                 System.out.println("Enter your username");
                                            //                 while(true)
                                            //                 {    
                                                //                     input = stdIn.readLine();

                //                     if(input.equalsIgnoreCase(email))
                //                     {
                    //                         System.out.println("Username can't be equal to your email! try again");
                    //                     }
                    //                     else if(input != null && !input.isEmpty())
                    //                     {
                        //                         break;
                        //                     }
                        //                     else
                        //                     {
                            //                         System.out.println("Error : Username was empty, try again.");
                            //                     }
                            //                 }
                            //                 out.println(input);
                            //                 break;
                            //             }
                            //             else if("alreadyregistered".equalsIgnoreCase(message))
                            //             {
                                //                 System.out.println("Email address is already in use");
                                //             }
                                //             else
                                //             {
                                    //                 System.out.println("invalid email");
                                    //             }
                                    
                                    //         }
                                    //         break;
                                    //     }
                                    //     else
                                    //     {
                                        //     System.out.println("wrong argument " + input + ". 'log in'/'register'");
                                        //     }
                                        // }
                                        // }
                                        // else
                                        // {
                                            //     while (this.connecting) { 
                                                //       System.out.print("");  
                                                //     }
            // }
            // userList += "";
            
            // send = new Thread(() -> {SendMessages();});
            // listen = new Thread(() -> {ListenForMessages();});
            // send.start();
            // listen.start();
            
            // }
            // catch(UnknownHostException e)
            // {
                //     System.out.println("can't find hostS");
                // }
                // catch(IOException e) 
                // {
                    //     System.out.println("IOException " + e.getMessage());
                    // }
                    
    }

    private void SendMessages()
    {
        // try 
        // {    
            
        
        
        // System.out.println("You can type messages now to chat or type \"exit\" to leave");
        chatLog += "You can send messages now to chat or type \"/exit\" to leave (\"/help\" for all commands)\n";
        textArea.setText(chatLog);
        
        // String message;
        
        while(true)
        {
            if(!socket.isConnected())
            {
                break;
            }
            // message = stdIn.readLine();
            // if("exit".equalsIgnoreCase(message))
            // {
                //     out.println(message);
                //     ClientDisconnect();
                //     break;
                // }
                // out.println(message);
                // out.flush();
            }
            // }
            // catch(IOException e){ System.out.println("IOException : " + e.getMessage());}
        }
        
        private void ListenForMessages()
    {
        try{
            String message;
            
            while (true)
            { 
                if(socket.isClosed())
                {
                    System.out.println("socket closed");
                    ClientDisconnect();
                    break;
                }
                
                if((message = in.readLine()) != null)
                {

                    if(message.startsWith("Duel;"))
                    {
                    System.out.println(message);
                    String duel = "";
                    String duelName = "";
                    String duelName2 = "";
                    String game = "";
                    for(int i = 5; i < message.length(); i++)
                    {
                        if(message.charAt(i) == ';')
                        {
                            for(int j = i + 1; j<message.length(); j++)
                            {
                                if(message.charAt(j) == ';')
                                {
                                    for(int k = j + 1; k < message.length(); k++)
                                    {
                                        if(message.charAt(k) == ';')
                                        {
                                            for(int l = k + 1; l < message.length(); l++)
                                            {
                                                if(message.charAt(l) == ';')
                                                {
                                                    break;
                                                }
                                                game += message.charAt(l);
                                            }
                                            break;
                                        }
                                        duelName2 += message.charAt(k);
                                    }
                                    break;
                                }
                                duelName += message.charAt(j);
                            }
                            break;
                        }
                        duel += message.charAt(i);
                    }
                    System.out.println(duel + " " + duelName + " " + duelName2 + " " + game);
                    if(duel.startsWith("playing"))
                    {
                        chatLog += ("(" + (LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")).toString()) + ") ");
                        chatLog += duelName + " is already playing a game!";
                        chatLog += "\n";
                        textArea.setText(chatLog);
                    }
                    else if(duel.startsWith("unknown"))
                    {
                        chatLog += ("(" + (LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")).toString()) + ") ");
                        chatLog += "Error: unknown username : " + duelName;
                        chatLog += "\n";
                        textArea.setText(chatLog);
                    }
                    else if(duel.startsWith("challange"))
                    {
                        chatLog += ("(" + (LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")).toString()) + ") ");
                        chatLog += "Player " + duelName + " challanges you to a game of " + game +"!" ;
                        chatLog += "\n";
                        textArea.setText(chatLog);
                        challange _challange = new challange(duelName, duelName2, game);
                        challanges.add(_challange);
                        challangeLabel.setText(challanges.get(0).challanger +  " wants to play " + challanges.get(0).game);
                        challanageSubPanel.setVisible(true);                        
                    }
                    else if(duel.startsWith("start")) //starts a game
                    {
                        gameFrame.dispose();
                        playingBot = false;
                        isPlaying = true;
                        acceptButton.setEnabled(false);
                        System.out.println("message " + message + "/ duelname:" + duelName + " duelname2:" + duelName2 + " game:" + game);
                        newGameGUI(duelName, duelName2, game, gameCoordinates);
                        if(message.endsWith("2"))
                        {
                            confirmAtGameFrame.setVisible(false);
                            txtOutputFieldAtGameFrame.setText("waiting for opponent...");
                            // button
                        }
                    }
                    else if(duel.startsWith("move"))
                    {
                        // duelname = x ; duelname2 = y ; game = player ;
                        System.out.println("duel move" + message);
                        nameCurrentTurnPlayer = game;
                        xCoordinateAtGameFrame.setText("");
                        yCoordinateAtGameFrame.setText("");
                        if(confirmAtGameFrame.isVisible())
                        {
                            txtOutputFieldAtGameFrame.setText("waiting for opponent...");
                            confirmAtGameFrame.setVisible(false);
                        }
                        else
                        {
                            txtOutputFieldAtGameFrame.setText("Your move...");
                            confirmAtGameFrame.setVisible(true);
                        }
                        drawMove(Integer.parseInt(duelName), Integer.parseInt(duelName2)-1);
                        
                    }
                    else if(duel.startsWith("end"))
                    {
                        System.out.println("game over");
                        gameFrame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
                        xCoordinateAtGameFrame.setVisible(false);
                        yCoordinateAtGameFrame.setVisible(false);
                        confirmAtGameFrame.setVisible(false);
                        resignAtGameFrame.setVisible(false);
                        txtOutputFieldAtGameFrame.setText("GAME OVER! " + duelName + " won the game!");
                        isPlaying = false;
                        acceptButton.setEnabled(true);
                        
                    }
                }
                else if(message.startsWith("updateUsers"))
                {
                    String newUserList = "";
                    for(int i = 12; i<message.length(); i++)
                    {
                        if(message.charAt(i) == ';')
                        {
                            newUserList += "\n";
                        }
                        else
                        {
                            newUserList += message.charAt(i);
                        }
                    }
                    userList = newUserList;
                    userListArea.setText(userList);
                    }
                    else
                    {
                    if(message.endsWith(" connected."))
                    {
                        
                        String joined = "";
                        for(int i = 0; i< message.length() -11; i++)
                        {
                            joined += message.charAt(i);
                        }
                        userList += joined;
                        userList += "\n";
                        userListArea.setText(userList);
                    }
                    else if(message.startsWith("Online Users :"))
                    {
                        // System.out.println(" online users list");
                        userList = "";
                        for(int i = 0; i<message.length(); i++)
                        {
                            if(message.charAt(i) == ';')
                            {
                                userList += "\n";
                            }
                            else
                            {
                                userList += message.charAt(i);
                            }
                        }
                        message = userList;
                        userListArea.setText(userList);
                    }
                    
                    chatLog += ("(" + (LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")).toString()) + ") ");
                    chatLog += message;
                    chatLog += "\n";
                    textArea.setText(chatLog);
                }
            }
                // System.out.println(message);
            }
        }
        catch(IOException e)
        {
            System.out.println("ioexception " + e.getMessage());
        }
    }
    public void ClientDisconnect() throws IOException
    {
        System.out.println("disconnecting client");
        send.interrupt();
        listen.interrupt();
        socket.close();
        in.close();
        out.close();
        username = "";
        password = "";
        email = "";
        this.connect = true;
        this.connecting = true;
        chatLog = "";
        userList = "Online Users : \n";
        userListArea.setText("");

        isPlaying = false;
        gameFrame.dispose();

        frame1.remove(mainPanel);
        frame1.revalidate();
        frame1.repaint();
        
        frame1.add(connectionPanel);
        logInPanel.setVisible(true);
        
        frame1.revalidate();
        frame1.repaint();
    }
    
    JFrame frame1 = new JFrame();
    
    JTextField portField = new JTextField();
    JTextField hostnameField = new JTextField();
    JTextField connectionInputField = new JTextField();
    
    JButton connectButton = new JButton("connect");
    JButton gotoLoginButton = new JButton("log in");
    JButton gotoRegisterButton = new JButton("register");
    JButton gotoLoginButtonAtRegister = new JButton("register");
    JButton sendMessageButton = new JButton("Send Command");
    JButton gotoMainAtChangePasswordPanel = new JButton("change password");
    JButton gotoMainPanel = new JButton("log in");
    JButton registerPasswordButton = new JButton("Connect");
    JButton gotoChangePassword = new JButton("change password");
    
    
    
    JPanel mainPanel = new JPanel();
    JPanel connectionPanel = new JPanel();
    JPanel inputPanel = new JPanel();
    JPanel userPanel = new JPanel();
    JPanel registerPanel = new JPanel(new GridBagLayout());
    JPanel logInRegisterPanel = new JPanel(new GridBagLayout());
    JPanel logInPanel = new JPanel(new GridBagLayout());
    JPanel registerPasswordPanel = new JPanel();
    JPanel changePasswordPanel = new JPanel(new GridBagLayout());
    // JLabel testLabel = new JLabel("click");
    
    JTextArea textArea = new JTextArea();
    JTextArea userListArea = new JTextArea();
    JTextField inputField = new JTextField("type a command...");
    JScrollPane scrollPane = new JScrollPane(textArea);
    JScrollPane userListScrollPane = new JScrollPane(userListArea);
    java.awt.Font font = new java.awt.Font("Serif", java.awt.Font.BOLD, 15);
    
    //challange-section
    JPanel challanageSubPanel = new JPanel(new GridBagLayout());
    JButton acceptButton = new JButton("accept");
    JButton rejectButton = new JButton("reject");
    JLabel challangeLabel = new JLabel();
    
    //connect-Panel
    JLabel txtPortAtConnectionPanel = new JLabel("Port: ");
    JLabel txtHostNameAtConnectionPanel = new JLabel("Hostname: ");
    
    //log in
    JLabel loginLabel = new JLabel();
    JLabel loginValidLabel = new JLabel();
    JTextField emailAtLogIn = new JTextField();
    JLabel txtPassword = new JLabel("Password: ");
    JTextField passwordAtLogIn = new JTextField();
    
    //change password
    JLabel txtNewPassword = new JLabel("new Password: ");
    JTextField passwortAtPasswordChangePanel = new JTextField();
    JLabel passwordChangeValidLabel = new JLabel();
    
    //register-email 
    JLabel txtEmailAddress = new JLabel("Email-Address: ");
    JLabel helpLabel = new JLabel("Email-Address: ");
    JTextField emailInputField = new JTextField();
    JLabel validLabel = new JLabel();
    JTextField usernameField = new JTextField();
    JLabel usernameLabel = new JLabel("Username: ");
    
    //registerpassword
    JLabel registerPasswordLabel = new JLabel("Password: ");
    JTextField registerPasswordField = new JTextField();
    JLabel registerPasswordValidLabel = new JLabel();
    public void ClientGUI()
    {
        //several Panels which can be set to visible(false/true)
        //start in logInRegisterPanel
        frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame1.setSize(1000, 750);
        frame1.setTitle("Client");
        // frame1.add(inputPanel);
        
        portField.setText("");
        connectionInputField.setText("");
        hostnameField.setText("");
        inputField.setText("");
        loginValidLabel.setText("");
        emailAtLogIn.setText("");
        passwordAtLogIn.setText("");
        passwortAtPasswordChangePanel.setText("");
        passwordChangeValidLabel.setText("");
        emailInputField.setText("");
        validLabel.setText("");
        usernameField.setText("");
        registerPasswordField.setText("");
        registerPasswordValidLabel.setText("");
        
        //-------------------connection panel -------------------------------
        connectionPanel.setBackground(Color.lightGray);
        connectionPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15,15,15,15);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.5;
        gbc.weighty = 0.1;
        connectionPanel.add(txtPortAtConnectionPanel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 0;
        connectionPanel.add(portField, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 1;
        connectionPanel.add(txtHostNameAtConnectionPanel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        connectionPanel.add(hostnameField, gbc);
        
        
        gbc.gridx = 1;
        gbc.gridy = 2;
        connectionPanel.add(connectButton, gbc);
        
        
        
        //----------------- log in and register Panel for Client -------------------------------
        
        
        logInRegisterPanel.setBackground(Color.lightGray);
        gotoLoginButton.setPreferredSize(new Dimension(100,50));
        gotoRegisterButton.setPreferredSize(new Dimension(100,50));
        logInRegisterPanel.add(gotoLoginButton);
        logInRegisterPanel.add(gotoRegisterButton);
        clearListeners(gotoLoginButton);
        clearListeners(gotoRegisterButton);
        gotoLoginButton.addActionListener(this);
        gotoRegisterButton.addActionListener(this);
        
        
        
        //------------ register Panel with email input -> leads to log in ------------------
        registerPanel.setBackground(Color.lightGray);
        registerPanel.setBorder(new EmptyBorder(15,15, 15, 15));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 0.5;
        gbc.weighty = 0.45;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        registerPanel.add(helpLabel,gbc);
        
        gbc.gridx=1;
        gbc.gridy=0;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 0.5;
        gbc.weighty = 0.45;
        gbc.fill=GridBagConstraints.HORIZONTAL;
        registerPanel.add(emailInputField,gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0.5;
        gbc.weighty = 0.45;
        registerPanel.add(usernameLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.weightx = 0.5;
        gbc.weighty = 0.45;
        registerPanel.add(usernameField, gbc);
        
        clearListeners(gotoLoginButtonAtRegister);
        gotoLoginButtonAtRegister.addActionListener(this);
        gbc.gridx=1;
        gbc.gridy=2;
        gbc.weightx = 0.5;
        gbc.weighty = 0.1;
        registerPanel.add(gotoLoginButtonAtRegister,gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 2;
        registerPanel.add(validLabel, gbc);
        
        //--------------- registerpasswordpanel -----------------------------------
        registerPasswordPanel.setBackground(Color.lightGray);
        registerPasswordPanel.setBorder(new EmptyBorder(15,15,15,15));
        registerPasswordPanel.setLayout(new GridBagLayout());
        
        gbc.fill = GridBagConstraints.BOTH;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.4;
        gbc.weighty = 0.2;
        registerPasswordPanel.add(registerPasswordLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.weightx = 0.4;
        gbc.weighty = 0.2;
        gbc.gridwidth = 2;
        registerPasswordPanel.add(registerPasswordField, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0.4;
        gbc.weighty = 0.2;
        gbc.gridwidth = 1;
        registerPasswordPanel.add(registerPasswordValidLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.weightx = 0.4;
        gbc.weighty = 0.2;
        registerPasswordPanel.add(registerPasswordButton,gbc);
        clearListeners(registerPasswordButton);
        registerPasswordButton.addActionListener(this);
        
        //--------------- logInPanel with password change --------------
        logInPanel.setBackground(Color.lightGray);
        logInPanel.setBorder(new EmptyBorder(15,15,15,15));
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 0.5;
        gbc.weighty = 0.5;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        logInPanel.add(txtEmailAddress,gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.weightx = 0.5;
        gbc.weighty = 0.5;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        logInPanel.add(emailAtLogIn,gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0.5;
        gbc.weighty = 0.5;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        logInPanel.add(txtPassword,gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.weightx = 0.5;
        gbc.weighty = 0.5;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        logInPanel.add(passwordAtLogIn,gbc);
        
        clearListeners(gotoChangePassword);
        gotoChangePassword.addActionListener(this);
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.weightx = 0.45;
        gbc.weighty = 0.5;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        logInPanel.add(gotoChangePassword,gbc);
        
        clearListeners(gotoMainPanel);
        gotoMainPanel.addActionListener(this);
        gbc.gridx = 2;
        gbc.gridy = 2;
        gbc.weightx = 0.45;
        gbc.weighty = 0.5;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        logInPanel.add(gotoMainPanel,gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.weightx = 0.1;
        gbc.weighty = 0.5;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        logInPanel.add(loginValidLabel, gbc);
        
        
        //--------------------------   changePasswordPanel  -------------------------------------
        changePasswordPanel.setBackground(Color.lightGray);
        changePasswordPanel.setBorder(new EmptyBorder(15,15,15,15));
        
        gbc.gridx=0;
        gbc.gridy=0;
        changePasswordPanel.add(txtNewPassword,gbc);
        
        gbc.gridx=1;
        gbc.gridy=0;
        changePasswordPanel.add(passwortAtPasswordChangePanel,gbc);
        
        clearListeners(gotoMainAtChangePasswordPanel);
        gotoMainAtChangePasswordPanel.addActionListener(this);
        gbc.gridx=1;
        gbc.gridy=1;
        changePasswordPanel.add(gotoMainAtChangePasswordPanel,gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 1;
        changePasswordPanel.add(passwordChangeValidLabel,gbc);
        
        
        //-------------------------- main-Panel with list of all clients and global chat --------------------------
        mainPanel.setBackground(Color.lightGray);
        // mainPanel.setSize(500, 500);
        mainPanel.setLayout(new GridBagLayout());
        // mainPanel.setPreferredSize(new Dimension(500, 500));
        
        inputPanel.setLayout(new BoxLayout(inputPanel, BoxLayout.X_AXIS));
        inputField.setFont(font);
        userPanel.setLayout(new BoxLayout(userPanel, BoxLayout.X_AXIS));
        
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setEditable(false);
        // textArea.setPreferredSize(new Dimension(500, 500));
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        // scrollPane.setPreferredSize(new Dimension(500, 500));
        // mainPanel.setBackground(Color.green);
        userListArea.setLineWrap(true);
        userListArea.setWrapStyleWord(true);
        userListArea.setEditable(false);
        userListArea.setText(userList);
        
        userListScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        userListScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        
        
        //GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15,15,15,15);
        gbc.fill = GridBagConstraints.BOTH;
        
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.weightx = 0.3;
        gbc.weighty = 0.5;
        
        mainPanel.add(userListScrollPane, gbc);
        
        
        GridBagConstraints cGbc = new GridBagConstraints();
        challanageSubPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        challanageSubPanel.setBackground(Color.GREEN);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0.3;
        gbc.weighty = 0.25;
        
        challanageSubPanel.setVisible(false);
        mainPanel.add(challanageSubPanel, gbc);
        
        cGbc.gridx = 0;
        cGbc.gridy = 0;
        cGbc.weightx = 1;
        cGbc.weighty = 0.6;
        
        challanageSubPanel.add(challangeLabel, cGbc);
        
        cGbc.gridx = 0;
        cGbc.gridy = 1;
        cGbc.weightx = 0.5;
        cGbc.weighty = 0.4;
        
        challanageSubPanel.add(acceptButton, cGbc);
        
        cGbc.gridx = 1;
        cGbc.gridy = 1;
        cGbc.weightx = 0.5;
        cGbc.weighty = 0.4;
        
        challanageSubPanel.add(rejectButton, cGbc);
        
        
        
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 2;
        gbc.weightx = 0.7;
        gbc.weighty = 0.8;
        
        mainPanel.add(scrollPane, gbc);
        
        // gbc.gridx = 0;
        // gbc.gridy = 1;
        
        // mainPanel.add(button1, gbc);
        
        // gbc.gridx = 0;
        // gbc.gridy = 2;
        
        // mainPanel.add(testTextField);
        inputPanel.add(inputField);
        inputPanel.add(sendMessageButton);
        // mainPanel.add(inputPanel);
        
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.gridheight = 1;
        gbc.weightx = 1;
        gbc.weighty = 0.2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(15,15,15,15);
        
        mainPanel.add(inputPanel, gbc);
        clearListeners(acceptButton);
        clearListeners(sendMessageButton);
        clearListeners(rejectButton);
        clearListeners(connectButton);
        sendMessageButton.addActionListener(this);
        for (ActionListener _listener : inputField.getActionListeners()) 
        {
            inputField.removeActionListener(_listener);
        }
        inputField.addActionListener(this);
        
        connectButton.addActionListener(this);
        
        acceptButton.addActionListener(this);
        rejectButton.addActionListener(this);
        
        
        //frame1.add(connectionPanel);
        
        // to change to another frame/panel: add it > set visible true
        // close old frames/panels
        
        frame1.setVisible(true);
        
        frame1.add(connectionPanel);
        connectionPanel.setVisible(true); 
        // frame1.add(logInRegisterPanel);
    }
    
    

    
    String username = "error";
    String email;
    String password;
    @Override
    public void actionPerformed(ActionEvent e)
    {
        try
        {
            if(e.getSource() == this.sendMessageButton || e.getSource() == this.inputField)
            {
                String input = inputField.getText();
                inputField.setText("");

                if("/exit".equalsIgnoreCase(input))
                {
                    ClientDisconnect();
                }
                else if ("/help".equalsIgnoreCase(input)) 
                {
                    chatLog += "/exit : to leave\n/duel <username> <connectfour/foody> : to play\n/computer <connectfour/foody> to play against a bot\n/msg <username> <message> : to privately message\n";
                    textArea.setText(chatLog);
                }
                else if("test".equalsIgnoreCase(input))
                {
                    // adminChatLog += ("(" + (LocalTime.now().toString()) + ") [Server] : ");
                    // adminChatLog += "test command \n";
                    // textArea.setText(adminChatLog);
                }
                else if (input.toLowerCase().startsWith("/duel "))
                {
                    if(this.isPlaying)
                    {
                        chatLog += "error: already playing a game!";
                        textArea.setText(chatLog);
                    }
                    else if(input.toLowerCase().trim().endsWith("connectfour") || input.toLowerCase().trim().endsWith("foody"))
                    {
                        String a = "Duel;start;";
                        
                        if(input.toLowerCase().trim().endsWith("connectfour"))
                        {
                            for(int i = 6; i < input.length(); i++)
                            {
                                if(i == input.length() -12)
                                {
                                    a += ";";
                                }
                                else 
                                {
                                    a+= input.charAt(i);
                                }
                            }
                        }
                        else if(input.toLowerCase().trim().endsWith("foody"))
                        {
                            for(int i = 6; i< input.length(); i++)
                            {
                                if(i == input.length() - 8)
                                {
                                    a += ";";
                                }
                                else
                                {
                                    a += input.charAt(i);
                                }
                            }
                        }
                        input = a;
                        out.println(input);
                        out.flush();
                    }
                    else
                    {
                        
                    }
                }
                else if(input.toLowerCase().startsWith("/computer "))
                {
                    if(!isPlaying)
                    {
                        if(input.toLowerCase().trim().equals("/computer connectfour"))
                        {
                            gameFrame.dispose();
                            newGame("You","Bot","connectfour",new int[7][6]);
                            
                            isPlaying = true;
                            acceptButton.setEnabled(false);
                            // System.out.println("message " + message + "/ duelname:" + duelName + " duelname2:" + duelName2 + " game:" + game);
                            newGameGUI("You", "Bot", "connectfour", gameCoordinates);
                            playingBot = true;
                        }
                        else if(input.toLowerCase().trim().equals("/computer foody"))
                        {
                            gameFrame.dispose();
                            newGame("You","Bot","foody",gameCoordinates);
                            isPlaying = true;
                            acceptButton.setEnabled(false);
                            newGameGUI("You","Bot","foody",gameCoordinates);
                            playingBot = true;
                        }
                        else
                        {
                            
                        }
                    }
                }
                else if(input.toLowerCase().startsWith("/msg "))
                {
                    String a = "String;private;";
                    int j = 0;
                    for (int i = 5; i<input.length(); i++)
                    {
                        if(input.charAt(i) == ' ')
                        {
                            j = i + 1;
                            break;
                        }
                        a += input.charAt(i);
                    }
                    a += ";";
                    for (int k = j; k < input.length(); k++)
                    {
                        a += input.charAt(k);
                    }
                    
                    input = a;
                    out.println(input);
                    out.flush();
                }
                else
                {
                    String a = "String;global;" + input;
                    
                    out.println(a);
                    out.flush();
                }

                }
                else if(e.getSource() == this.connectButton)
                {
                    this.port = Integer.parseInt(portField.getText());
                    this.hostname = hostnameField.getText();
                    this.connect = false;
                    socket = new Socket(this.hostname, this.port);
                    if(socket != null)
                    {
                        System.out.println("socket not null");
                        if(socket.isConnected())
                        {
                            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                            out = new PrintWriter(socket.getOutputStream(), true);
                            stdIn = new BufferedReader(new InputStreamReader(System.in));
                            
                            System.out.println("connected");
                            frame1.remove(connectionPanel);
                            frame1.revalidate();
                            frame1.repaint();
                            frame1.add(logInRegisterPanel);                
                            logInRegisterPanel.setVisible(true);
                            frame1.revalidate();
                            frame1.repaint();
                            
                        }
                        else{this.connect = true;}
                    }
                    else{this.connect = true;}
                    
                }
                //----------------------------------- Navigation between panels -------------------------------------
                else if(e.getSource() == this.gotoLoginButton)
                {
                    frame1.remove(logInRegisterPanel);
                    frame1.revalidate();
                    frame1.repaint();
                    
                    frame1.add(logInPanel);
                    logInPanel.setVisible(true);
                    
                    frame1.revalidate();
                    frame1.repaint();
                    out.println("log in");
                    String f = in.readLine();
                    System.out.println(f);
                    
                }
                else if(e.getSource() == this.gotoLoginButtonAtRegister){
                    System.out.println(username);
                    username = usernameField.getText();
                    System.out.println(usernameField.getText());
                    email = emailInputField.getText();
                    if(username.trim().isEmpty() || email.trim().isEmpty())
                    {
                        validLabel.setVisible(true);
                        validLabel.setText("Email/ Username is empty!");
                        emailInputField.setText("");
                        usernameField.setText("");
                    }
                else if(username.toLowerCase().equalsIgnoreCase(email.toLowerCase()))
                {
                    validLabel.setVisible(true);
                    validLabel.setText("Username needs to be different from the email");
                    emailInputField.setText("");
                    usernameField.setText("");
                }
                else
                {
                    
                    System.out.println(email);
                    out.println(email);
                    String valid = in.readLine();
                    System.out.println(valid);
                    if(valid.equalsIgnoreCase("valid"))
                    {
                        
                        frame1.remove(registerPanel);
                        frame1.revalidate();
                        frame1.repaint();
                        
                        frame1.add(registerPasswordPanel);
                        registerPasswordPanel.setVisible(true);
                        
                        frame1.revalidate();
                        frame1.repaint();
                    }
                    else
                    {
                        System.out.println("else");
                        validLabel.setVisible(true);
                        validLabel.setText(valid);
                        emailInputField.setText("");
                    }
                }
            }
            else if(e.getSource() == this.registerPasswordButton)
            {
                password = registerPasswordField.getText();
                if(password.trim().isEmpty())
                {
                    registerPasswordValidLabel.setText("password is empty!");
                }
                else
                {
                    out.println(password);
                    String message = in.readLine();
                    if(message.equalsIgnoreCase("valid"))
                    {
                        out.println(username);
                        
                        frame1.remove(registerPasswordPanel);
                        frame1.revalidate();
                        frame1.repaint();
                        
                        frame1.add(mainPanel);
                        mainPanel.setVisible(true);
                        
                        frame1.revalidate();
                        frame1.repaint();
                        this.connecting = false;
                        
                        send = new Thread(() -> {SendMessages();});
                        listen = new Thread(() -> {ListenForMessages();});
                        send.start();
                        listen.start();
                    }
                }
            }
            else if(e.getSource() == this.gotoRegisterButton){
                frame1.remove(logInRegisterPanel);
                frame1.revalidate();
                frame1.repaint();
                
                frame1.add(registerPanel);
                registerPanel.setVisible(true);
                
                frame1.revalidate();
                frame1.repaint();
                out.println("register");
                String f = in.readLine(); 
                System.out.println(f);
                
            }
            else if(e.getSource() == this.gotoChangePassword){
                
                email = emailAtLogIn.getText();
                password = passwordAtLogIn.getText();
                if(email.trim().isEmpty() || password.trim().isEmpty())
                {
                    loginValidLabel.setVisible(true);
                    loginValidLabel.setText("Email or password empty!");
                }
                else
                {
                    out.println(email);
                    String message = in.readLine();
                    
                    if(message.equalsIgnoreCase("valid"))
                    {
                        out.println(password);
                        message = in.readLine();
                        if(message.equalsIgnoreCase("valid"))
                        {
                            out.println("change");
                            frame1.remove(logInPanel);
                            frame1.revalidate();
                            frame1.repaint();
                            
                            frame1.add(changePasswordPanel);
                            registerPanel.setVisible(true);
                            
                            frame1.revalidate();
                            frame1.repaint();
                            
                        }
                        else
                        {
                            loginValidLabel.setVisible(true);
                            loginValidLabel.setText("incorrect password");
                            
                        }
                    }
                    else
                    {
                        loginValidLabel.setVisible(true);
                        loginValidLabel.setText("incorrect email or password");
                        
                    }
                }
            }
            else if(e.getSource() == this.gotoMainAtChangePasswordPanel)
            {
                password = passwortAtPasswordChangePanel.getText();
                
                if(password.trim().isEmpty())
                {
                    passwordChangeValidLabel.setVisible(true);
                    passwordChangeValidLabel.setText("invalid password");
                }
                else
                {
                    out.println(password);
                    out.println("chat");
                    frame1.remove(changePasswordPanel);
                    frame1.revalidate();
                    frame1.repaint();
                    
                    frame1.add(mainPanel);
                    mainPanel.setVisible(true);
                    
                    frame1.revalidate();
                    frame1.repaint();
                    this.connecting = false;

                    send = new Thread(() -> {SendMessages();});
                    listen = new Thread(() -> {ListenForMessages();});
                    send.start();
                    listen.start();
                }
            }
            else if(e.getSource() == this.gotoMainPanel){
                email = emailAtLogIn.getText();
                password = passwordAtLogIn.getText();
                if(email.trim().isEmpty() || password.trim().isEmpty())
                {
                    loginValidLabel.setVisible(true);
                    loginValidLabel.setText("Email or password empty!");
                }
                else
                {
                    out.println(email);
                    String message = in.readLine();
                    
                    if(message.equalsIgnoreCase("valid"))
                    {
                        out.println(password);
                        message = in.readLine();
                        if(message.equalsIgnoreCase("valid"))
                        {
                            out.println("chat");
                            frame1.remove(logInPanel);
                            frame1.revalidate();
                            frame1.repaint();
                            
                            frame1.add(mainPanel);
                            mainPanel.setVisible(true);
                            
                            frame1.revalidate();
                            frame1.repaint();
                            this.connecting = false;
                            
                            send = new Thread(() -> {SendMessages();});
                            listen = new Thread(() -> {ListenForMessages();});
                            send.start();
                            listen.start();
                        }
                        else
                        {
                            loginValidLabel.setVisible(true);
                            loginValidLabel.setText("incorrect password");

                        }
                    }
                    else
                    {
                        loginValidLabel.setVisible(true);
                        loginValidLabel.setText("incorrect email or password");
                    }
                }
            }
            else if(e.getSource() == this.acceptButton)
            {
                String accepted = "Duel;accepted;" + challanges.get(0).game + ";"+ challanges.get(0).challanger + ";" + challanges.get(0).recipient;
                if(!isPlaying)
                {
                    challanges.remove(0);
                    
                    if(challanges.isEmpty())
                    {
                        challanageSubPanel.setVisible(false);
                    }
                    out.println(accepted);
                }
                
                
            }
            else if(e.getSource() == this.rejectButton)
            {
                String rejected = "Duel;rejected;" + challanges.get(0).challanger + ";" + challanges.get(0).recipient;
                challanges.remove(0);
                if(challanges.isEmpty())
                {
                    challanageSubPanel.setVisible(false);
                }
                else
                {
                    challangeLabel.setText(challanges.get(0).challanger + " wants to play " + challanges.get(0).game);
                }
                out.println();
            }
            else if(e.getSource() == this.confirmAtGameFrame)
            {
                int x= -1;
                int y = -1;
                System.out.println(chosenGame + " : " + xCoordinateAtGameFrame.getText() + " " + yCoordinateAtGameFrame.getText() + "Lengths" + gameCoordinates.length + " " + gameCoordinates[0].length);
                try 
                {
                    x = Integer.parseInt(xCoordinateAtGameFrame.getText());
                    if(chosenGame.equalsIgnoreCase("connectfour"))
                    {
                        y=0; // y gets selected in connectfour.java
                    }
                    else
                    {
                        y = Integer.parseInt(yCoordinateAtGameFrame.getText());
                    }
                    // System.out.println(zellen[x-1][y].getBackground().toString() + x + y);
                    if(0<=x && (x-1)< gameCoordinates.length && 0<=y && y<gameCoordinates[0].length && ((chosenGame.equalsIgnoreCase("foody") && cells[x][y].getBackground() == Color.white) || (cells[x][y].getBackground() == Color.white && chosenGame.equalsIgnoreCase("connectfour"))))
                    {
                        x++;
                        if(chosenGame.equalsIgnoreCase("foody"))
                        {
                            // y--;
                            // x--;
                        }
                        
                        y++;
                        if(playingBot)
                        {
                            playMoveAgainstBot(x, y);
                        }
                        else
                        {
                            txtOutputFieldAtGameFrame.setText("valid input " + gameCoordinates.length + " " + gameCoordinates[0].length);
                            if(nameCurrentTurnPlayer.equals(namePlayer1))
                            {
                                out.println("Duel;move;" + namePlayer2 + ";" + x + ";" + y);
                            }
                            else
                            {
                                out.println("Duel;move;" + namePlayer1 + ";" + x + ";" + y);
                            }
                        }
                    }
                    else
                    {
                        txtOutputFieldAtGameFrame.setText("invalid input");
                    }
                }
                catch (NumberFormatException nfe) 
                {
                    txtOutputFieldAtGameFrame.setText("invalid input");
                }
                
            }
            else if (e.getSource()== this.resignAtGameFrame)
            {
                if(playingBot)
                {
                    gameFrame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
                    xCoordinateAtGameFrame.setVisible(false);
                    yCoordinateAtGameFrame.setVisible(false);
                    confirmAtGameFrame.setVisible(false);
                    resignAtGameFrame.setVisible(false);
                    txtOutputFieldAtGameFrame.setText("GAME OVER! " + "Bot" + " won the game!");
                    isPlaying = false;
                    playingBot = false;
                    acceptButton.setEnabled(true);
                }
                else
                {
                    out.println("Duel;resign;");
                    // System.out.println("resigned");
                }
            }
            
            
            System.out.println("action Performed " + e.getActionCommand());
        }
        catch(IOException IOe)
        {
            System.out.println("ioexception " + IOe.getMessage());
            try 
            {
                ClientDisconnect();
                
            } 
            catch (IOException e2) 
            {
                System.out.println("ioexception2 " + e2.getMessage());
            }
        }
        
    }
    
    // only if playingBot = true!!
    private void newGame(String player1, String player2, String game, int[][] field)
    {
        System.out.println(player1 + " [players]" + player2);
        if(game.equalsIgnoreCase("connectfour"))
        {
            Game = new ConnectFour(1, game, new Player(player1, true, 1), new Player(player2,false,2), field);
        }
        else if(game.equalsIgnoreCase("foody"))
        {
            Game = new Foody(1, game, new Player(player1, true, 1), new Player(player2, false, 2), field);
        }
    }
    
    // only if playingBot == true!
    private void playMoveAgainstBot(int x, int y)
    {
        if(Game.pickedGame.equalsIgnoreCase("connectfour"))
        {
            Game.move(Game.player1, x, y);
        }
        else
        {
            Game.move(Game.player1, x, y);
        }
        int moveX = Game.moveList.get(Game.moveList.size()-1).x();
        int moveY = Game.moveList.get(Game.moveList.size()-1).y();
        boolean gameOver = Game.GameIsOver;
        int winner = Game.winner;
        String movePlayer1 = Game.player1.playerName;
        String movePlayer2 = Game.player1.playerName;

        nameCurrentTurnPlayer = Game.player1.playerName;
        xCoordinateAtGameFrame.setText("");
        yCoordinateAtGameFrame.setText("");
        if(Game.pickedGame.equalsIgnoreCase("connectfour"))
        {
            drawMove(moveX-1,moveY);
        }
        else
        {
            drawMove(moveX, moveY);

        }

        if(gameOver)
        {
            System.out.println("gameover");
            gameFrame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
            xCoordinateAtGameFrame.setVisible(false);
            yCoordinateAtGameFrame.setVisible(false);
            confirmAtGameFrame.setVisible(false);
            resignAtGameFrame.setVisible(false);
            if(winner == 0)
            {
                txtOutputFieldAtGameFrame.setText("GAME OVER! nobody won the game!");
            }
            else if(winner == 1)
            {
                txtOutputFieldAtGameFrame.setText("GAME OVER! You won the game!");
            }
            else if(winner == 2)
            {
                txtOutputFieldAtGameFrame.setText("GAME OVER! Bot won the game!");
            }
            isPlaying = false;
            acceptButton.setEnabled(true);
            Game = null;
            return;
        }
        
        Game.move(Game.player2, 0, 0);
        moveX = Game.moveList.get(Game.moveList.size()-1).x();
        moveY = Game.moveList.get(Game.moveList.size()-1).y();
        gameOver = Game.GameIsOver;
        winner = Game.winner;
        
        nameCurrentTurnPlayer = Game.player2.playerName;
        xCoordinateAtGameFrame.setText("");
        yCoordinateAtGameFrame.setText("");
        if(Game.pickedGame.equalsIgnoreCase("connectfour"))
        {
            drawMove(moveX-1,moveY);
        }
        else
        {
            drawMove(moveX, moveY);
        }

        if(gameOver)
        {
            System.out.println("gameover");
            gameFrame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
            xCoordinateAtGameFrame.setVisible(false);
            yCoordinateAtGameFrame.setVisible(false);
            confirmAtGameFrame.setVisible(false);
            resignAtGameFrame.setVisible(false);
            if(winner == 0)
            {
                txtOutputFieldAtGameFrame.setText("GAME OVER! nobody won the game!");
            }
            else if(winner == 1)
            {
                txtOutputFieldAtGameFrame.setText("GAME OVER! You won the game!");
            }
            else if(winner == 2)
            {
                txtOutputFieldAtGameFrame.setText("GAME OVER! Bot won the game!");
            }
            isPlaying = false;
            acceptButton.setEnabled(true);
            Game = null;
        }
        
    }


    //--------------Method to draw in Foody----------------
    private void drawSlots(int x, int y, String _playerName){
        for(;x<rows;x++){
            drawSlotsDown(x, y, _playerName);
        }
    }
    
    //Method to draw all lots below x and y 
    private void drawSlotsDown(int x, int y, String _playerName){
        if(cells[x][y].getBackground().equals(Color.WHITE)){
            if(_playerName.equals(namePlayer1)){
                cells[x][y].setBackground(Color.GREEN);
            }
            if(_playerName.equals(namePlayer2)){
                cells[x][y].setBackground(Color.PINK);
            }
            

            if(y+1<columns){
                drawSlotsDown(x, y+1, _playerName);
            }
        }
    }
    Game Game;
    boolean isPlaying = false;
    boolean playingBot = false;
    int[][] gameCoordinates = new int[7][6];
    String chosenGame=""; //to lowercase
    int rows = gameCoordinates.length;
    int columns = gameCoordinates[0].length;
    String namePlayer1="player1";
    String namePlayer2="player2";
    String nameCurrentTurnPlayer=namePlayer1;
    
    JFrame gameFrame = new JFrame();

    JLabel txtOutputFieldAtGameFrame = new JLabel("your turn");
    
    JButton confirmAtGameFrame = new JButton("confirm");
    JTextField xCoordinateAtGameFrame = new JTextField();
    JTextField yCoordinateAtGameFrame = new JTextField();
    
    JPanel[][] cells = new JPanel[rows][columns];    
    JPanel topBarAtGameFrame = new JPanel();
    JPanel botBarAtGameFrame = new JPanel();
    JButton resignAtGameFrame = new JButton("resign");
    JPanel centerPanelAtGameFrame = new JPanel();
    JLabel player1NameAtGameFrame = new JLabel();
    JLabel player2NameAtGameFrame = new JLabel();
    JPanel gamecoordinatesAtGameFrame = new JPanel();
    
    private void newGameGUI(String _player1, String _player2, String _game, int[][] boardCoordinates)
    {
        clearListeners(confirmAtGameFrame);
        clearListeners(resignAtGameFrame);
        gameFrame.dispose();
        namePlayer1 = _player1;
        namePlayer1 = _player2;

        this.chosenGame = _game;
        player1NameAtGameFrame.setText(_player1);
        player2NameAtGameFrame.setText(_player2);
        gameFrame.setSize(800,600);
        gameFrame.setTitle(chosenGame);
        gameFrame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        gameFrame.addWindowListener(new WindowAdapter(){@Override public void windowClosing(WindowEvent e) {isPlaying = false;}});
        gameFrame.getContentPane().setBackground(Color.lightGray);
        gameFrame.setLayout(new BorderLayout());

        txtOutputFieldAtGameFrame.setPreferredSize(new Dimension(800,20));
        txtOutputFieldAtGameFrame.setHorizontalAlignment(JLabel.CENTER);
        txtOutputFieldAtGameFrame.setText(_game);
        
        topBarAtGameFrame.add(txtOutputFieldAtGameFrame);
        gameFrame.add(topBarAtGameFrame, BorderLayout.NORTH);

        resignAtGameFrame.setPreferredSize(new Dimension(150,30));
        resignAtGameFrame.setVisible(true);
        resignAtGameFrame.addActionListener(this);
        botBarAtGameFrame.add(resignAtGameFrame);
        
        xCoordinateAtGameFrame.setPreferredSize(new Dimension(150,30));
        botBarAtGameFrame.add(xCoordinateAtGameFrame);
        yCoordinateAtGameFrame.setPreferredSize(new Dimension(150,30));
        botBarAtGameFrame.add(yCoordinateAtGameFrame);
        xCoordinateAtGameFrame.setText("");
        yCoordinateAtGameFrame.setText("");
        xCoordinateAtGameFrame.setVisible(true);
        if(_game.equalsIgnoreCase("connectfour"))
        {
            yCoordinateAtGameFrame.setVisible(false);
        }
        else
        {
            yCoordinateAtGameFrame.setVisible(true);
        }

        confirmAtGameFrame.setVisible(true);
        confirmAtGameFrame.addActionListener(this);
        confirmAtGameFrame.setPreferredSize(new Dimension(150,30));
        botBarAtGameFrame.add(confirmAtGameFrame);

        gameFrame.add(botBarAtGameFrame, BorderLayout.SOUTH);

        centerPanelAtGameFrame.setLayout(new BorderLayout());
    
        player1NameAtGameFrame.setPreferredSize(new Dimension(150,30));
        player1NameAtGameFrame.setBorder(new EmptyBorder(10,10,10,10));
        player1NameAtGameFrame.setForeground(Color.GREEN);
        centerPanelAtGameFrame.add(player1NameAtGameFrame,BorderLayout.WEST);

        player2NameAtGameFrame.setPreferredSize(new Dimension(150,30));
        player2NameAtGameFrame.setHorizontalAlignment(JLabel.RIGHT);
        player2NameAtGameFrame.setBorder(new EmptyBorder(10,10,10,10));
        player2NameAtGameFrame.setForeground(Color.PINK);
        centerPanelAtGameFrame.add(player2NameAtGameFrame,BorderLayout.EAST);

        
        gamecoordinatesAtGameFrame.setBackground(Color.BLACK);
        gamecoordinatesAtGameFrame.removeAll();
        gamecoordinatesAtGameFrame.revalidate();
        gamecoordinatesAtGameFrame.repaint();

        gamecoordinatesAtGameFrame.setLayout(new GridLayout(columns, rows ,2,2));
        for(int i = 0; i < columns; i++){
            for(int j =0; j < rows; j++){
                JPanel zelle = new JPanel();
                zelle.setBackground(Color.WHITE);
                cells[j][i] = zelle;
                JLabel zelleLabel = new JLabel(j + "," +i);
                zelleLabel.setForeground(Color.lightGray);
                zelle.add(zelleLabel);
                gamecoordinatesAtGameFrame.add(zelle);
            }
        }

        



        centerPanelAtGameFrame.add(gamecoordinatesAtGameFrame,BorderLayout.CENTER);

        gameFrame.add(centerPanelAtGameFrame);



    

        gameFrame.setVisible(true);
        System.out.println("finish gameframe");
    }

    private void drawMove(int x, int y)
    {
        if(chosenGame.equals("connectfour"))
        {             // x-1                                
            if(cells[x][y].getBackground().equals(Color.WHITE)){
                if(nameCurrentTurnPlayer.equals(namePlayer1)){
                    cells[x][y].setBackground(Color.GREEN);
                }
                else
                {
                    cells[x][y].setBackground(Color.PINK);
                }
                gameFrame.revalidate();
                gameFrame.repaint();
            }
            else
            {
                txtOutputFieldAtGameFrame.setText("Slot is already occupied");
            }
            //connectfour
            gameFrame.revalidate();
            gameFrame.repaint();
        }
        if(chosenGame.equals("foody")){
            
            if(cells[x][y].getBackground().equals(Color.WHITE)){
                drawSlots(x, y, nameCurrentTurnPlayer);
                gameFrame.revalidate();
                gameFrame.repaint();
            }
            else
            {
                txtOutputFieldAtGameFrame.setText("Slot is already occupied");
            }
                                            
            if(!(cells[0][0].getBackground().equals(Color.WHITE))){
                // player lost
                
            }
        }
    }

    private void clearListeners(JButton _button) 
    {
        for (ActionListener _listener : _button.getActionListeners()) {
            _button.removeActionListener(_listener);
        }        
    }
}