/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.connectfourserver;

import java.util.Random;

public class Foody extends Game implements GameLog
{
    int [][] oldBoard;

    //Constructor for foody
    public Foody(int _gameId, String game, Player player1, Player player2, int[][] Field){
        minXField = 2;
        minYField = 2;
        //Start();
        pickedGame= game;
        this.player1 = player1;
        this.player2 = player2;
        GameBoardCoordinates = Field;
        MoveCounter = 0;
        gameId = _gameId;
        columns = GameBoardCoordinates.length; // disclaimer : columns in foody = rows in connectfour i think
        rows = GameBoardCoordinates[0].length; // disclaimer : rows in foody == columns in connectfour i think

        board = new Board(rows, columns);
        GameBoardCoordinates = Field;
        GameIsOver = false;
        winner = 0;
        for(int i = 0; i < columns ; i++)
        {
            for(int j= 0; j < rows; j++)
            {
                GameBoardCoordinates[i][j] = 0;
            }
        }
    }

    @Override
    public void move(Player currentTurnPlayer, int x, int y)
    {
        x--;
        y--;
        boolean moveIsOver=false;
        
        //int x = -1;      //x is column
        //int y = -1;     //y is row

        //gameBoardCoordinates[x][y] access with [column][row]


        //Player move
        if(currentTurnPlayer.isHuman)
        {
            if(slotIsEmpty(x,y))
            {
                newMove(x, y, currentTurnPlayer);
            }
            else
            {
                System.out.println("slot is already occupied");
            }
            
            //save
            oldBoard = new int[columns-x][rows-y];
        
            for(int i=0; i<columns-x;i++)
            {
                for(int j= 0; j<rows-y; j++)
                {
                    oldBoard[i][j]=GameBoardCoordinates[i+x][j+y];
                }
            }
        }

        //computers turn 
        else{
            //case 1: defeat
            //only loose if there's no other available move
            if(GameBoardCoordinates[1][0]!=0 && GameBoardCoordinates[0][1]!=0){
                x=0;
                y=0;
                moveIsOver=true;
                newMove(x, y, currentTurnPlayer);
            }

            //case 2 : win by occupying last column
            //1st column empty,and [1][0] occupied
            //[0][1] has to be empty
            if(GameBoardCoordinates[1][0]!=0 && !moveIsOver){
                x=0;
                y=1;
                moveIsOver=true;
                newMove(x, y, currentTurnPlayer);
            }

            //case 3 : win by occupying last row
            //1st row empty, and [0][1] occupied
            //[1][0] has to b empty 
            if(GameBoardCoordinates[0][1]!=0 && !moveIsOver){
                x=1;
                y=0;
                moveIsOver=true;
                newMove(x, y, currentTurnPlayer);
            }

            Random random = new Random();

            // find an empty slot
            while(!moveIsOver){
                
                //pick a random x
                x = random.nextInt(columns);
                
                //if x==0 : y != 0
                if(x==0){
                    y = random.nextInt(rows-1)+1;
                }
                else{
                    y=random.nextInt(rows);
                }

                //if slot is empty : break
                if(slotIsEmpty(x,y)){
                    newMove(x, y, currentTurnPlayer);
                    break;
                }                
            }
        }     

        drawSlots(x, y, currentTurnPlayer.playerIndex);
        board.UpdateBoard(GameBoardCoordinates);

        //check if the current player lost
        if(x==0 && y==0){
            GameIsOver=true;
            if(currentTurnPlayer.playerIndex == 1)
            {
                winner = 2;
            }
            else
            {
                winner = 1;
            }
            System.out.println("Player " + currentTurnPlayer.playerIndex + " lost the game!");
        }
    }

    
    public boolean slotIsEmpty(int x, int y){
        if(GameBoardCoordinates[x][y]==0){
            return true;
        }
        return false;
    }
    
    private void drawSlots(int x, int y, int playerIndex){
        for(;x<columns;x++){
            drawSlotsDown(x, y, playerIndex);
        }
    }

    //draws all slots downwards from x,y
    private void drawSlotsDown(int x, int y, int playerIndex){
        if(slotIsEmpty(x, y)){
            GameBoardCoordinates[x][y] = playerIndex;

            //if not at the end : draw next slot below
            if(y+1<rows){
                drawSlotsDown(x, y+1, playerIndex);
            }
        }
        return;
    }

    public void removeLastMove()
    {
        moveList.remove(moveList.size()-1);
    }

    public void newMove(int x, int y, Player _player)
    {
        Move move = new Move(_player.playerIndex, moveList.size(), x, y );
        moveList.add(move);
        MoveCounter++;
    }
}