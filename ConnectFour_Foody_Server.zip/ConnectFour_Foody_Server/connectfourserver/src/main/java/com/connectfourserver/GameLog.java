/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.connectfourserver;

public interface GameLog
{
    public void newMove(int x, int y, Player player);

    public void removeLastMove();

    public record Move(int playerIndex, int _move, int x, int y){}

}
