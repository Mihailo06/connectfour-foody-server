/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.connectfourserver;

import javax.swing.JPanel;
public class Board extends JPanel
{
    static int columns;
    static int rows;

    public Board(int _rows, int _columns)
    {   
        this.columns = _columns;
        this.rows = _rows;   
    }

    public static void UpdateBoard(int[][] _feld) //prints the Game to Console.
    {
        
        for(int i = -1; i< rows+1; i++)
        {
            if(i == -1)
            {
                for(int j = 0; j< columns+ 2; j++)
                {
                    System.out.print("#");
                }
            }
            else if(i == rows)
            {
                for(int j = 0; j< columns + 2; j++)
                {
                    
                    
                    System.out.print("#");
                    
                }
                System.out.println();
                break;
            }
            else
            {
                System.out.print("#");
                for(int j = 0; j<columns; j++)
                {
                    if(_feld[j][i] == 1)
                    {
                        System.out.print("1");
                    }
                    else if(_feld[j][i] == 2)
                    {
                        System.out.print("2");
                    } 
                    else
                    {
                     System.out.print("_");
                    }
                }
                System.out.print("#");
            }
            System.out.println("");

        }

    }

}
