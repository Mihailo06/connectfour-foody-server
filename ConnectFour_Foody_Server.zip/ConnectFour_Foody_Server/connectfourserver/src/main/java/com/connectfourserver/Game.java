/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.connectfourserver;

import java.util.ArrayList;
import java.util.List;

// stores gameData!

public abstract class Game{

    public Player player1;
    public Player player2;
    public Board board;
    public List<String> numlist = new ArrayList<>();
    public List<GameLog.Move> moveList = new ArrayList<>(); // List of all Moves
    public int rows;
    public int columns;
    // static Scanner scanner;
    public int[][] GameBoardCoordinates;
    public boolean GameIsOver;
    public int winner;
    public int MoveCounter;
    public int minXField;
    public int minYField;
    public String pickedGame;
    public abstract void move(Player currentTurnPlayer, int x, int y);
    public int gameId;
    public int currentPlayer;


    public static void main(String args[])
    {
    }    
}