/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.connectfourserver;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.UUID;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class Server implements ActionListener
{
    //for Mail.java 
    Session newSession = null;
	MimeMessage mimeMessage = null;

    static ServerSocket serverSocket;
    BufferedReader stdIn;
    int port;
    int backlog;   
    private final List<EventHandler<ServerConnectedEventArgs>> clientConnectedHandler = new ArrayList<>();
    private final List<EventHandler<ServerDisconnectedEventArgs>> clientDisconnectHandler = new ArrayList<>();
    private final List<Socket> clientSockets = Collections.synchronizedList(new ArrayList<>()); // list for  sockets
    private List<client> clientList = new ArrayList<>(); //list for their records

    private List<Game> gameList = new ArrayList<>();
    private int gameIdCounter = 1;

    String chatLog = "";
    String adminChatLog = "";
    String userList = "Online Users : \n";
    public static void main(String args[])
    {
        try 
        {
            Server server = new Server(7799, 20);
            server.startServer();;
        }
        catch (IOException e) 
        {
            System.out.println(e.getMessage());
        }
    }
    
    public Server(int port, int backlog)
    {
        ServerGUI();
        this.port = port;
        this.backlog = backlog;
        // listener subscribes to the event clientConnected : when client connects : handle with system outprintln
        this.addClientConnectedListener((sender, eventArgs) -> 
        {
            System.out.println(" Client " + eventArgs.getClientAddress() + " connected at Port : " + eventArgs.getClientPort());
            
        });

        // listener subscribes to the event clientConnected : when client connects handle the event with following code 
        this.addClientDisconnectedListener((sender, eventArgs) -> 
        {
            System.out.println(clientList.size());
            System.out.println("Client " + eventArgs.getClientAddress() + " disconnected " + eventArgs.getClientPort());
            for(client _client : clientList )
            {
                if(_client.clientSocket.getPort() == eventArgs.getClientPort())
                {
                    chatLog += ("(" + (LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")).toString()) + ") " + _client.clientUsername + " disconnected");
                    chatLog += "\n";
                    adminChatLog += ("(" + (LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")).toString()) + ") " + _client.clientUsername + " disconnected");
                    adminChatLog += "\n";
                    textArea.setText(adminChatLog);

                    clientList.remove(_client);
                    String newUserList = "Online Users : \n";
                    for(client _client2 : clientList)
                    {
                        _client2.clientOut.println(_client.clientUsername + " disconnected.");
                        newUserList += _client2.clientUsername;
                        newUserList += "\n";

                    }
                    userList = newUserList;
                    userListArea.setText(userList);
                    String outUserList = "updateUsers;";
                    for(client _client2 : clientList)
                    {

                        for(int i = 0; i<userList.length(); i++)
                        {
                            if(userList.charAt(i) == '\n')
                            {
                                outUserList+= ";";
                            }
                            else
                            {
                                outUserList += userList.charAt(i);
                            }
                        }
                        _client2.clientOut.println(outUserList);
                    }

                    for(int i = 0; i<gameList.size(); i++)
                    {
                        if(gameList.get(i).player1.playerName.equals(_client.clientUsername))
                        {
                            for(int j = 0; j<clientList.size(); j++)
                            {
                                if(clientList.get(j).clientUsername.equals(gameList.get(i).player2.playerName))
                                {
                                    clientList.get(j).clientOut.println("Duel;end;" + gameList.get(i).player2.playerName);
                                }
                            }
                            gameList.remove(i);
                        }
                        else if(gameList.get(i).player2.playerName.equals(_client.clientUsername))
                        {
                            for(int j = 0; j<clientList.size(); j++)
                            {
                                if(clientList.get(j).clientUsername.equals(gameList.get(i).player1.playerName))
                                {
                                    clientList.get(j).clientOut.println("Duel;end;" + gameList.get(i).player1.playerName);
                                }
                            }
                            gameList.remove(i);
                        }
                    }

                    break;
                
                }
            }
        });
    }
    
    
    public void startServer() throws IOException
    {
        System.out.println("starting server");
        serverSocket = new ServerSocket(port, backlog, InetAddress.getByName("0.0.0.0")); // ServerSocket, port : 7799 for now
        Runtime.getRuntime().addShutdownHook(new Thread(() ->  {
            try{
                StopServer(); //shutdownhook thread, to close all sockets in case of this program terminating
                
            }
            catch(IOException e){}
        }));

        stdIn = new BufferedReader(new InputStreamReader(System.in));
        new Thread(() -> { try
            {
                while(true)
                {
                    String input = stdIn.readLine();
                    if("stop".equalsIgnoreCase(input))
                    {
                        StopServer();
                         break;
                    }
                }
            }catch(IOException e)
            {
                System.out.println(e.getMessage());
            }}).start();
        
        while(true) 
        {
            Socket clientSocket = serverSocket.accept(); // waits for a new connection
            System.out.println("Client Connected" + clientSocket.getInetAddress());
            
            synchronized (clientSockets)
            {
                clientSockets.add(clientSocket); //synchronized : only 1 client can modify the list at a time 
            }

            new Thread(() -> {handleClient(clientSocket);}).start(); // new thread for all code related to the new client

        }
    }
   
    // thread log in/ register and input/output streams between client and server
    private void handleClient(Socket clientSocket)
    {
        String emailPassword = ""; 
        try(BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
            )
        {
            String name = "error"; //error : case register / log in was skipped for whatever reason
            String username = "error"; // name : the user's name, username : email, password : password
            String password = "error";
            String message; // clients input message
            String input; // case the server has any inputs
            boolean register = false;
            
            
            while(true) //log in/ register 
            {

                    message = in.readLine();
                    if("log in".equalsIgnoreCase(message))
                {
                    out.println("Please enter your email address");
                    while(true)
                    {

                        message = in.readLine(); // email
                        String[] userData = ReadUserData(message, 0); // checks for the email in userData.txt
                        System.out.println(userData[0] + " found");

                        if(!(userData==null) && (userData[0] !=null))
                        {
                            String check1 = "invalid";
                            out.println("valid");
                            name = message;
                            while(true)
                            {
                                message = in.readLine(); // password
                                if(message.equals(userData[1]))
                                {
                                    check1 = "valid";
                                    out.println("valid");
                                    password = userData[1];

                                    username = userData[2];
                                    if(username.isEmpty())
                                    {
                                        System.out.println("error username is empty");
                                        username = "error";
                                    }

                                    while(true)
                                    { 
                                        message = in.readLine();
                                        if("change".equalsIgnoreCase(message))
                                        {
                                            message = in.readLine();
                                            ChangeUserPassword(name, message);
                                            
                                        }
                                        else
                                        {
                                            break;
                                        }
                                    }
                                    break;

                                }
                                else
                                {
                                    out.println("invalid");
                                    check1 = "invalid";
                                    break;
                                }
                            }
                            if(check1.equalsIgnoreCase("valid"))
                            {
                                System.out.println("valid breaking");
                                break;
                            }
                            System.out.println("another while");
                        }
                        else
                        {
                            out.println("invalid");
                        }
                    }
                    
                    
                    System.out.println("register " + register);
                    break;
                }
                else if("register".equalsIgnoreCase(message))
                {
                    register = true;
                    out.println("Please enter your email address");
                    while (true)
                    { 
                        System.out.print("email  essage");
                        message = in.readLine(); // String name (email)

                        System.out.println(message);
                        boolean emailValid = false;
                        String[] nullcheck = ReadUserData(message, 0);

                        String check;
                        if(nullcheck != null)
                        {
                            check = nullcheck[0];
                        }    
                        else
                        {
                            check = null;
                        }
                        //System.out.println(" email check :" + check + " stringlength :" + check.length() + message);
                        if(check != null)
                        {
                            emailValid = false;
                            System.out.println("email already taken");
                        }
                        else if(message.isEmpty())
                        {
                            emailValid = false;
                        }
                        else{
                            emailPassword = sendPasswordEmail(message, UUID.randomUUID().toString());
                        }
                        
                        
                        
                        System.out.println(emailPassword);
                        
                        if(emailPassword != null)
                        {
                            emailValid = true;
                        }

                        if(emailValid)
                        {
                            name = message;
                            out.println("valid");
                            
                            while (true)
                            { 
                                message = in.readLine(); // String password
                                if(emailPassword.equals(message))
                                {
                                    out.println("valid");
                                    password=emailPassword;
                                    break;
                                }
                                else
                                {
                                    out.println("invalid");
                                }
                            }
                            
                            
                            // out.println("valid");
                            message = in.readLine(); // String Username
                            username = message;
                            System.out.println(message);
                            break;
                                
                        }   
                        else
                        {
                            if( ReadUserData(message, 0) != null)
                            {
                                out.println("invalid");
                            }
                            else if(!ReadUserData(message, 0)[0].isEmpty())
                            {
                                out.println("alreadyregistered");
                            }
                            else
                            {
                                out.println("invalid");
                            }

                        } 
                    }
                }
                else
                {
                    
                }
                break;
            }
            
                
            client _Client = new client(clientSocket, name, username, password, in, out, false);
            for(client _client : clientList)
            {
                _client.clientOut.println(_Client.clientUsername + " connected.");
            }

            userList += _Client.clientUsername;
            userList += "\n";
            userListArea.setText(userList);

            adminChatLog += ("(" + (LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")).toString()) + ") " + _Client.clientUsername + " joined the chat");
            adminChatLog += "\n";
            chatLog += ("(" + (LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")).toString()) + ") " + _Client.clientUsername + " joined the chat");
            chatLog += "\n";
            textArea.setText(adminChatLog);

            clientList.add(_Client);
            if(register == true)
            {
                System.out.println("register saveuserdata " + register);
                SaveUserData(_Client.clientName, _Client.password, _Client.clientUsername);
            }
            register = false;
            String outUserList = "";
            for(int i = 0; i<userList.length(); i++)
            {
                if(userList.charAt(i) == '\n')
                {
                    outUserList+= ";";
                }
                else
                {
                    outUserList += userList.charAt(i);
                }
            }
            _Client.clientOut.println(outUserList);
            while((message = in.readLine()) != null)
            {
                System.out.println("IN READ LINE!");
                if(false)
                {

                }
                else if(message.startsWith("String;global;")) // global messages
                {
                    String a = "";
                    for(int i = 14; i<message.length(); i++)
                    {
                        a += message.charAt(i);
                    }
                    message = a;
                    System.out.println( "Client (" + clientSocket.getInetAddress() + ") :" + message );
                    chatLog += ("(" + (LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")).toString()) + ") " + _Client.clientUsername + " : ");
                    chatLog += message;
                    chatLog += "\n";
                    adminChatLog += ("(" + (LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")).toString()) + ") " + _Client.clientUsername + " : ");
                    adminChatLog += message;
                    adminChatLog += "\n";
                    textArea.setText(adminChatLog);

                    for(client _client : clientList)
                    {
                        _client.clientOut.println(_Client.clientUsername + " (" +  clientSocket.getPort() + ") : " + message);   
                    }
                }
                else if(message.startsWith("String;private;")) // /msg <user>
                {
                    String recipient = "";
                    String directMessage = "";
                    for(int i = 15; i<message.length(); i++)
                    {
                        if(message.charAt(i) != ';')
                        {
                            recipient += message.charAt(i);
                        }
                        else
                        {
                            for(int j = i+1; j<message.length(); j++)
                            {
                                directMessage += message.charAt(j);
                            }
                            break;
                        } 
                    }
                    boolean found = false;
                    for(int i = 0; i< clientList.size(); i++)
                    {
                        if(clientList.get(i).clientUsername.equals(recipient))
                        {
                            found = true;
                            clientList.get(i).clientOut().println("From " + _Client.clientUsername + " : " + directMessage);
                            _Client.clientOut.println("To " + recipient + " : " + directMessage);
                            
                            adminChatLog += ("(" + (LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")).toString()) + ") " + _Client.clientUsername + " -> " + recipient+ " :" + directMessage);
                            adminChatLog += "\n";
                            textArea.setText(adminChatLog);

                            break;
                        }
                    }
                    if(!found)
                    {
                        _Client.clientOut.println("error : unknown user " + recipient);
                    }
                }
                else if(message.startsWith("Duel;start;")) //game request : doesn't start a game yet
                {
                    System.out.println(message);
                    String duelName = "";
                    for(int i = 11; i< message.length(); i++)
                    {
                        if(message.charAt(i) == ';')
                        {
                            break;
                        }
                        duelName += message.charAt(i);
                    }
                    System.out.println(duelName);
                    boolean found = false;
                    for(int i = 0; i< clientList.size(); i++)
                    {
                        if(clientList.get(i).clientUsername.equals(duelName))
                        {
                            found = true;
                            if(clientList.get(i).isPlaying)
                            {
                                _Client.clientOut.println("Duel;playing;" + duelName);
                            }
                            else
                            {
                                String game = "";
                                if(message.toLowerCase().trim().endsWith("connectfour"))
                                {
                                    game = "connectfour";
                                }
                                else
                                {
                                    game = "foody";
                                }
                                clientList.get(i).clientOut().println("Duel;challange;" + _Client.clientUsername + ";" + clientList.get(i).clientUsername() + ";" + game);
                            }
                        }
                    }
                    if(!found)
                    {
                        _Client.clientOut.println("Duel;unknown;" + duelName); // user not found
                    }
                    
                }
                else if(message.startsWith("Duel;accepted;")) // game accepted - a client can only play one game at a time
                {
                    String game = "";
                    String recipient = "";
                    String challanger = "";
                    System.out.println("message  " + message);
                    for(int i = 14; i < message.length(); i++)
                    {
                        if(message.charAt(i) == ';')
                        {
                            for(int j = i + 1; j<message.length(); j++)
                            {
                                if(message.charAt(j) == ';')
                                {
                                    for(int k = j + 1; k < message.length(); k++)
                                    {
                                        recipient += message.charAt(k);

                                    }
                                    break;
                                }
                                challanger += message.charAt(j);
                            }
                            break;
                        }
                        game += message.charAt(i);
                    }
                    for(int i = 0; i< clientList.size();i++)
                    {
                        System.out.println(clientList.get(i).clientUsername + " " + challanger + " " + recipient);
                        if(clientList.get(i).clientUsername.equalsIgnoreCase(challanger))
                        {
                            clientList.get(i).clientOut.println("Duel;start;" + challanger + ";" + recipient + ";"+ game + ";2");
                        }
                        else if(clientList.get(i).clientUsername.equalsIgnoreCase(recipient))
                        {
                            clientList.get(i).clientOut.println("Duel;start;" + challanger + ";" + recipient + ";"+ game + ";1");
                        }
                    }
                    newGame(recipient,challanger,game, new int[7][6]);
                }
                else if(message.startsWith("Duel;rejected;")) // Game rejected
                {
                    String recipient = "";
                    String challanger = "";
                    for(int i = 14; i < message.length(); i++)
                    {
                        if(message.charAt(i) == ';')
                        {
                            for(int j = i + 1; j<message.length(); j++)
                            {
                                recipient += message.charAt(j);
                            }
                            break;
                        }
                        challanger += message.charAt(i);
                    }
                    for(int i =0; i<clientList.size(); i++)
                    {
                        if(clientList.get(i).clientUsername == challanger)
                        {
                            clientList.get(i).clientOut().println(recipient + " rejected your challange");
                        }
                    }
                }
                else if(message.startsWith("Duel;move;")) // plays a move
                {
                    String moveName = "";
                    String moveX = "";
                    String moveY = "";
                    for(int i = 10; i< message.length(); i++)
                    {
                        if(message.charAt(i) == ';')
                        {
                            for(int j = i + 1; j<message.length();j++)
                            {
                                if(message.charAt(j) == ';')
                                {
                                    for(int k= j + 1; k<message.length(); k++)
                                    {
                                        moveY += message.charAt(k);
                                    }
                                    break;
                                }
                                moveX += message.charAt(j);
                            }
                            break;
                        }
                        moveName += message.charAt(i);
                    }
                    System.out.println("movee " + message + "   " + moveName  +"(" + _Client.clientUsername + ")" + moveX + " " +moveY);
                    System.out.println(moveX);
                    System.out.println(moveY);
                    moveName = _Client.clientUsername;
                    playMove(moveName, Integer.parseInt(moveX), Integer.parseInt(moveY));
                }
                else if(message.startsWith("Duel;resign;")) // player resigns
                {
                    // System.out.println(message);
                    for (int i = 0; i < gameList.size(); i++)
                    {
                        if(_Client.clientUsername.equals(gameList.get(i).player1.playerName))
                        {
                            // System.out.println("username resign found");
                            for(int j =0; j< clientList.size(); j++)
                            {
                                // System.out.println("resign1");
                                if(clientList.get(j).clientUsername.equals(gameList.get(i).player2.playerName))
                                {
                                    // System.out.println("resign2");
                                    clientList.get(j).clientOut().println("Duel;end;" + gameList.get(i).player2.playerName);
                                    _Client.clientOut().println("Duel;end;" + gameList.get(i).player2.playerName);
                                    gameList.remove(i);
                                    break;
                                }
                            }
                            break;
                        }
                        else if(_Client.clientUsername.equals(gameList.get(i).player2.playerName))
                        {
                            // System.out.println("username2 resign found");
                            for(int j = 0; j < clientList.size(); j++)
                            {
                                if (clientList.get(j).clientUsername.equals(gameList.get(i).player1.playerName))
                                {
                                    // System.out.println("resign22");
                                    clientList.get(j).clientOut().println("Duel;end;" + gameList.get(i).player1.playerName);
                                    _Client.clientOut().println("Duel;end;" + gameList.get(i).player1.playerName);
                                    gameList.remove(i);
                                    break;
                                }
                            }
                            break;
                        }
                    }
                }
                
            }
        }
        catch(IOException e )   
        {
            System.out.println("Client disconnected " + clientSocket.getInetAddress() + " e: " + e.getMessage() );
        }
        finally
        {
            clientDisconnected(clientSocket);
            synchronized(clientSockets)
            {
                clientSockets.remove(clientSocket);
            }
            try{clientSocket.close();}
            catch(IOException e)
            {
                System.out.println("error closing socket " + clientSocket.getInetAddress() + " error : " +e.getMessage() );
            }
        }
    }

    // listener subscribes to the event 
    private void addClientConnectedListener(EventHandler<ServerConnectedEventArgs> listener)
    {
        clientConnectedHandler.add(listener);
    }

    // listener subscribes to the event
    private void addClientDisconnectedListener(EventHandler<ServerDisconnectedEventArgs> listener)
    {
        clientDisconnectHandler.add(listener);
    }
    
    // lets the listeners know when an event happens
    public void clientConnected(Socket clientSocket)
    {
        ServerConnectedEventArgs eventArgs = new ServerConnectedEventArgs(clientSocket);
        for(EventHandler<ServerConnectedEventArgs> listener : clientConnectedHandler)
        {
            listener.handle(this, eventArgs);
        }
    } 

    // lets the listeners know when an event happens
    public void clientDisconnected(Socket clientSocket)
    {
        ServerDisconnectedEventArgs eventArgs = new ServerDisconnectedEventArgs(clientSocket);
        for(EventHandler<ServerDisconnectedEventArgs> listener : clientDisconnectHandler)
        {
            listener.handle(this, eventArgs);
        }
    }

    // stops server and disconnects all clients
    public void StopServer() throws IOException
    {
        System.out.println("Stopping server...");
            
        
        for(client _client : clientList)
        {
            _client.clientOut.println("[SERVER]: stopping...");
            _client.clientIn.close();
            _client.clientOut.close();
            _client.clientSocket.close();
        }
        serverSocket.close();
    }
        
    // record with client data
    private record client(Socket clientSocket, String clientName, String clientUsername, String password, BufferedReader clientIn, PrintWriter clientOut, boolean isPlaying)
    {
    }

    // synchronised, so that only 1 thread can access the file userData.txt at a time
    private final Object fileLock = new Object();

    // string: the string you're searching for in userData.txt
    // StringIndex : 0 , case string = email
    //               1 , case string = password
    //               2 , case string = username
    // breaks(:= ;) are there to determine wether email/password/username should get read, 'cause what if somebody uses somebody's name as his password
    public String[] ReadUserData(String string, int StringIndex)
    {
        synchronized(fileLock){
        try
        {
            // System.out.println("Reading user data");

            String[] userData = new String[3]; //string array with email, password and username
            String data = ""; // all of userData.txt's data as a String
            int breaks = 0;
            String word = ""; // the word currently being read
            FileInputStream in = new FileInputStream("UserData");
            byte[] bytesToRead = new byte[in.available()]; //file length
            boolean found = false; //if the word was found
            int foundPass = 0; //if 1 read username next instead of password;
            if(in.available()==0){
                return null;
            }

            in.read(bytesToRead);
            data = ByteToString(bytesToRead); 

            for(int i = 0; i < data.length(); i++)
            {
                if(!found)
                {
                    if(data.charAt(i) != ';') // if there's a ';' : word is successfully read and it will begin to read the next word
                    {
                        word += data.charAt(i);
                    }
                    else
                    {
                        if(word.equalsIgnoreCase(string) && (breaks % 3 == StringIndex)) //correct word was found (if searching for password it shouldnt read  a name)
                        {
                            found = true;
                            userData[0] = word;
                        }
                        word = "";
                        breaks++;
                    }
                }
                else
                {
                    if(data.charAt(i) != ';')
                    {
                        word += data.charAt(i);
                    }
                    else
                    {
                        if(foundPass == 0)
                        {
                            userData[1] = word;
                            foundPass++;
                            word = "";
                        }
                        else
                        {
                            userData[2] = word;
                            break;
                        }
                        
                    }
                }
            }
            in.close();
            return userData;
        }
        catch(IOException e)
        {
            System.out.println(e.getMessage());
            return null;
        }
        }
    }

    // Saves data in the file UserData.txt (append : writes the data at the end of the file) : <email>;<password>;<username>;
    public void SaveUserData(String email, String password, String username )
    {
        synchronized(fileLock){
        try
        {
            FileOutputStream out = new FileOutputStream("UserData", true);
            String a = ";";
            byte[] bytesToWritebreak = StringToByte(a);
            
            byte[] bytesToWriteEmail = StringToByte(email);
            byte[] bytesToWritePassword = StringToByte(password);
            byte[] bytesToWriteUsername =StringToByte(username);
             
            
            out.write(bytesToWriteEmail);
            out.write(bytesToWritebreak);
            out.write(bytesToWritePassword);
            out.write(bytesToWritebreak);
            out.write(bytesToWriteUsername);
            out.write(bytesToWritebreak);

            out.close();
        }catch(FileNotFoundException e)
        {
            System.out.println(e.getMessage());
        }catch(SecurityException e)
        {
            System.out.println(e.getMessage());
        }catch(IOException e)
        {System.out.println(e.getMessage());}
        }
    }

    // append = false : fileoutputstream overwrites the data with out.write
    // get the old passwords length, copy the data infront of the old password begins,
    // write new password and the rest of the data which came after the old password
    public void ChangeUserPassword(String email, String replacement)
    {
        synchronized (fileLock) {
            try
        {
            String data = ""; // String with userData
            String word = ""; // word currently being read
            int breaks = 0; // semicolumns in the string
            FileInputStream in = new FileInputStream("UserData");
            byte[] bytesToRead = new byte[in.available()]; // data length
            boolean found = false; //if the word was read/found
            
            int oldLength = 0;
            int oldWordLength = 0;
            int newWordLength = replacement.length();
            String newData = "";
            
            in.read(bytesToRead);
            data = ByteToString(bytesToRead);

            for(int i = 0; i < data.length(); i++)
            {
                if(!found)
                {
                    if(data.charAt(i) != ';') // reading word, case of ';' complete word is read
                    {
                        word += data.charAt(i);
                    }
                    else
                    {
                        if(word.equalsIgnoreCase(email) && (breaks % 3 == 0)) // correct word was found (e.g. if searching for email it should be an email that you found not a password)
                        {
                            found = true;
                            oldLength = i;
                        }
                        word = "";
                        breaks++;
                        
                    }
                }
                else
                {
                    if(data.charAt(i) != ';')
                    {
                        word += data.charAt(i);
                    }
                    else
                    {
                            oldWordLength = word.length(); // searching for the length of the old password
                            break;   
                    }
                }
            }
            boolean addWord = true;
            for(int i = 0; i < data.length(); i++)
            {
                if(i <= oldLength)
                {
                    newData += data.charAt(i);
                }
                else
                {
                    if(addWord)
                    {
                        newData += replacement;
                        addWord = false;
                        i += oldWordLength;
                    }
                    newData += data.charAt(i);
                }
            }
            FileOutputStream out = new FileOutputStream("UserData", false);
            out.write(StringToByte(newData));
            in.close();
            out.close();;
        }
        catch(IOException e)
        {
            System.out.println(e.getMessage());
        }
        }
    }

    public byte[] StringToByte(String string)
    {
        byte[] bytes = new byte[string.length()];
        for(int i = 0; i < string.length(); i++)
        {
            bytes[i] = (byte)string.charAt(i); 
        }
        return bytes;
    }

    public String ByteToString(byte[] bytes)
    {
        String string = "";
        for(int i = 0; i<bytes.length; i++)
        {
            char c = (char)bytes[i];
            string += c;
        }

        return string;

    }

    public Server(){};

    public static String sendPasswordEmail(String emailRecipient, String generatedPassword)
    {
        try
		{
            // System.out.println("0");
			Server mail = new Server();
            // System.out.println("1");
			mail.setupServerProperties();
            // System.out.println("2");
			mail.draftEmail(emailRecipient, generatedPassword);
            // System.out.println("3");
			mail.sendEmail();
            return generatedPassword;

		}
		catch(AddressException e)
		{
            System.out.println("Addressexception e " + e.getMessage());
            return null;
        }
		catch(MessagingException e)
		{
            System.out.println("Messagingexception e " + e.getMessage());
            return null;
		}
		catch(IOException e)
		{
            System.out.println("IOexception e " + e.getMessage());
            return null;
		}

	}


	private void sendEmail() throws MessagingException
    {
		String fromUser = "javatestapp4@gmail.com";  //Enter sender email id
		String fromUserPassword = "jkcqbhvehzsyotgz";  //Enter sender generated app-password , this will be authenticated by gmail smtp server
		String emailHost = "smtp.gmail.com";
		Transport transport = newSession.getTransport("smtp");
		transport.connect(emailHost, fromUser, fromUserPassword);
		transport.sendMessage(mimeMessage, mimeMessage.getAllRecipients());
		transport.close();
		System.out.println("Email sent!!!");
	}

	private MimeMessage draftEmail(String emailRecipient, String generatedPassword) throws AddressException, MessagingException, IOException
    {
		String emailSubject = "java server connectfour password!";
		String emailBody = "Your password is: " + generatedPassword;
		mimeMessage = new MimeMessage(newSession);
		
        mimeMessage.setFrom(new InternetAddress("javatestapp4@gmail.com"));

		mimeMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(emailRecipient));

		mimeMessage.setSubject(emailSubject);
   
		 MimeBodyPart bodyPart = new MimeBodyPart();
		 bodyPart.setContent(emailBody,"html/text");
		 MimeMultipart multiPart = new MimeMultipart();
		 multiPart.addBodyPart(bodyPart);
		 mimeMessage.setContent(multiPart);

		 mimeMessage.setText(emailBody);
		 return mimeMessage;
	}

	private void setupServerProperties()
    {
		Properties properties = System.getProperties();
        //case value:465 can't connect to the SMTP Host
        //case value:587 Username and Password not accepted
		properties.put("mail.smtp.port", "587");
		properties.put("mail.smtp.auth", "true");
		properties.put("mail.smtp.starttls.enable", "true");
		newSession = Session.getDefaultInstance(properties,null);
	}

    JFrame frame1 = new JFrame();
    JPanel mainPanel = new JPanel();
    JPanel inputPanel = new JPanel();
    JPanel userPanel = new JPanel();
    // JLabel testLabel = new JLabel("click");
    JButton sendMessageButton = new JButton("Send Command");
    JTextArea textArea = new JTextArea();
    JTextArea userListArea = new JTextArea();
    JTextField inputField = new JTextField("type a command...");
    JScrollPane scrollPane = new JScrollPane(textArea);
    JScrollPane userListScrollPane = new JScrollPane(userListArea);
    Font font = new Font("Serif", java.awt.Font.BOLD, 15);

    public void ServerGUI()
    {
        frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame1.setLocation(600, 250);
        frame1.setSize(1000, 750);
        // frame1.add(inputPanel);
        mainPanel.setBackground(Color.lightGray);
        // mainPanel.setSize(500, 500);
        mainPanel.setLayout(new GridBagLayout());
        // mainPanel.setPreferredSize(new Dimension(500, 500));
        
        inputPanel.setLayout(new BoxLayout(inputPanel, BoxLayout.X_AXIS));
        inputField.setFont(font);
        userPanel.setLayout(new BoxLayout(userPanel, BoxLayout.X_AXIS));

        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setEditable(false);
        // textArea.setPreferredSize(new Dimension(500, 500));
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        // scrollPane.setPreferredSize(new Dimension(500, 500));
        // mainPanel.setBackground(Color.green);
        userListArea.setLineWrap(true);
        userListArea.setWrapStyleWord(true);
        userListArea.setEditable(false);
        userListArea.setText(userList);
        
        userListScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        userListScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15,15,15,15);
        gbc.fill = GridBagConstraints.BOTH;

        
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.weightx = 0.3;
        gbc.weighty = 0.8;
        
        mainPanel.add(userListScrollPane, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.weightx = 0.7;
        gbc.weighty = 0.8;
        
        mainPanel.add(scrollPane, gbc);
        
        // gbc.gridx = 0;
        // gbc.gridy = 1;
        
        // mainPanel.add(button1, gbc);
        
        // gbc.gridx = 0;
        // gbc.gridy = 2;
        
        // mainPanel.add(testTextField);
        inputPanel.add(inputField);
        inputPanel.add(sendMessageButton);
        // mainPanel.add(inputPanel);
        
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.weightx = 1;
        gbc.weighty = 0.2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(15,15,15,15);
        
        mainPanel.add(inputPanel, gbc);
        
        sendMessageButton.addActionListener(this);
        inputField.addActionListener(this);
        
        frame1.add(mainPanel);
        // frame1.pack();
        frame1.setVisible(true);

        adminChatLog += "stop : stop server; test : test, games : list of live games, view <gameId> : watch a live game!\n";
        textArea.setText(adminChatLog);
        
    }




    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == this.sendMessageButton || e.getSource() == this.inputField)
        {
            String input = inputField.getText();
            inputField.setText("");
            try{

                if("stop".equalsIgnoreCase(input)) // stop
                {
                    adminChatLog += ("(" + (LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")).toString()) + ") [Server] : ");
                    adminChatLog += "stopping Server...\n";
                    chatLog += ("(" + (LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")).toString()) + ") [Server] : ");
                    chatLog += "stopping Server...\n";
                    textArea.setText(adminChatLog);
                    StopServer();
                }
                else if("test".equalsIgnoreCase(input)) //test
                {
                    adminChatLog += ("(" + (LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")).toString()) + ") [Server] : ");
                    adminChatLog += "test command \n";
                    textArea.setText(adminChatLog);
                }
                else if("games".equalsIgnoreCase(input)) // list of all ongoing games
                {
                    adminChatLog += ("(" + (LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")).toString()) + ") [Server] : ")+"CURRENTLY ONGOING GAMES!:\n";
                    String liveGames = "ID|Game|Player1|Player2\n";
                    for(int i = 0; i< gameList.size(); i++)
                    {
                        liveGames += gameList.get(i).gameId + "|" + gameList.get(i).pickedGame + "|" + gameList.get(i).player1.playerName + "|"+gameList.get(i).player2.playerName + "\n";
                    }
                    adminChatLog += liveGames;
                    textArea.setText(adminChatLog);
                }
                else if(input.startsWith("view ")) // usage "view <gameId>" : shows the GUI of an ongoing live game for the server
                {
                    for(int i = 0; i< gameList.size(); i++)
                    {
                        String a = gameList.get(i).gameId + "";
                        if(("view " + a).trim().equalsIgnoreCase(input.trim()))
                        {
                            watchingGame = gameList.get(i).gameId;
                            watchGame();
                        }
                    }
                }
            }
            catch(IOException IOe)
            {
                System.out.println(" IOExcection ActionPerformed " + IOe.getMessage());
            }
        }
        else if(false )
        {

        }
        System.out.println("action Performed" + e.getActionCommand());

    }

    //starts a new game for 2 player
    private synchronized int newGame(String player1, String player2, String game, int[][] field)
    {
        // System.out.println(player1 + " [players]" + player2);
        int gameId = gameIdCounter;
        gameIdCounter++;
        if(game.equalsIgnoreCase("connectfour"))
        {
            ConnectFour _game = new ConnectFour(gameId, game, new Player(player1, true, 1), new Player(player2,true,2), field);
            gameList.add(_game);
        }
        else if(game.equalsIgnoreCase("foody"))
        {
            Foody _game = new Foody(gameId, game, new Player(player1, true, 1), new Player(player2,true,2), field);
            gameList.add(_game);
        }


        return gameId;
    }

    //plays the move with Game.Move()
    private void playMove(String player, int x, int y)
    {
        System.out.println("playing move" + gameList.size());
        for(int i = 0; i<gameList.size(); i++)
        {
            System.out.println("iterating");
            System.out.println(player);
            System.out.println(gameList.get(i).player1.playerName);
            System.out.println(gameList.get(i).player2.playerName);
            if(gameList.get(i).player1.playerName.equals(player) || gameList.get(i).player2.playerName.equals(player))
            {
                System.out.println("player " + gameList.get(i).player1.playerName + " playre2 " +gameList.get(i).player2.playerName+ " player " + player);
                if(gameList.get(i).player1.playerName.equals(player))
                {
                    System.out.println("playing move" + i +  gameList.get(i).player1.playerName);
                    gameList.get(i).move(gameList.get(i).player1, x, y); // plays a move
                }
                else
                {
                    System.out.println("finsihed playing move");
                    gameList.get(i).move(gameList.get(i).player2, x, y); // plays a move
                    System.out.println("finished playing move");
                }
                int moveX = gameList.get(i).moveList.get(gameList.get(i).moveList.size()-1).x();
                int moveY = gameList.get(i).moveList.get(gameList.get(i).moveList.size()-1).y();
                boolean gameOver = gameList.get(i).GameIsOver;
                int winner = gameList.get(i).winner; //if somebody won
                // int movePlayer = spielList.get(i).zugList.get(spielList.get(i).zugList.size()).playerIndex();
                String movePlayer1 = gameList.get(i).player1.playerName;
                String movePlayer2 = gameList.get(i).player2.playerName;
                boolean exception = false;
                for(int j = 0; j <clientList.size(); j++)
                {
                    if(clientList.get(j).clientUsername.equals(movePlayer1) || clientList.get(j).clientUsername.equals(movePlayer2))
                    {
                        if(gameList.get(i).pickedGame.equalsIgnoreCase("connectfour"))
                        {
                            clientList.get(j).clientOut().println("Duel;move;" + (moveX-1) + ";" + (moveY+1) + ";" + player);
                        }
                        else
                        {
                            clientList.get(j).clientOut().println("Duel;move;" + (moveX) + ";" + (moveY +1) + ";" + player);
                        }
                        if(gameOver)
                        {
                            if(winner == 0)
                            {
                                clientList.get(j).clientOut().println("Duel;end;nobody"); // tie : no winners
                            }
                            else if(winner == 1)
                            {
                                clientList.get(j).clientOut().println("Duel;end;" + movePlayer1); // player 1 won
                            }
                            else if(winner == 2)
                            {
                                clientList.get(j).clientOut().println("Duel;end;" + movePlayer2); // player 2 won
                            }
                            if(exception)
                            {
                                gameList.remove(i);
                                return;
                            }
                            exception = true; // to prevent an exception when iterating
                        }
                    }
                }
            }
        }
        UpdateGame(); // updates the game GUI for the server
    }

    int watchingGame = -1; //game id for watching games
    
    JFrame gameFrame = new JFrame(); //gameFrame so that the server can view games

    JLabel txtOutputLabelAtGameFrame = new JLabel("");
    
    
    //each slot in the Game is it's own JPanel, which get stored in the slots array for later modification
    JPanel[][] slots = new JPanel[7][6];    
    
    JPanel TopPanelAtGameFrame = new JPanel();
    JPanel midPanelAtGameFrame = new JPanel();
    JLabel player1NameAtGameFrame = new JLabel();
    JLabel player2NameAtGameFrame = new JLabel();
    JPanel gameBoardAtGameFrame = new JPanel();
    
    private void watchGame()
    {
        int g = getGameFromId(watchingGame); // index for the gameList
        if(g ==-1)
        {
            watchingGame = -1;
            return;
        }

        player1NameAtGameFrame.setText(gameList.get(g).player1.playerName);
        player2NameAtGameFrame.setText(gameList.get(g).player2.playerName);
        gameFrame.setSize(800,600);
        gameFrame.setTitle(gameList.get(g).pickedGame);
        gameFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        gameFrame.addWindowListener(new WindowAdapter(){@Override public void windowClosing(WindowEvent e) {watchingGame = -1;}});
        gameFrame.getContentPane().setBackground(Color.lightGray);
        gameFrame.setLayout(new BorderLayout());

        //textfield to output data
        txtOutputLabelAtGameFrame.setPreferredSize(new Dimension(800,20));
        txtOutputLabelAtGameFrame.setHorizontalAlignment(JLabel.CENTER);
        TopPanelAtGameFrame.add(txtOutputLabelAtGameFrame);
        gameFrame.add(TopPanelAtGameFrame, BorderLayout.NORTH);

        
        //mid panel which the client can see too
        midPanelAtGameFrame.setLayout(new BorderLayout());
    
        player1NameAtGameFrame.setPreferredSize(new Dimension(150,30));
        player1NameAtGameFrame.setBorder(new EmptyBorder(10,10,10,10));
        player1NameAtGameFrame.setForeground(Color.BLUE);
        midPanelAtGameFrame.add(player1NameAtGameFrame,BorderLayout.WEST);

        player2NameAtGameFrame.setPreferredSize(new Dimension(150,30));
        player2NameAtGameFrame.setHorizontalAlignment(JLabel.RIGHT);
        player2NameAtGameFrame.setBorder(new EmptyBorder(10,10,10,10));
        player2NameAtGameFrame.setForeground(Color.RED);
        midPanelAtGameFrame.add(player2NameAtGameFrame,BorderLayout.EAST);

        
        gameBoardAtGameFrame.setBackground(Color.BLACK);
        gameBoardAtGameFrame.removeAll();
        gameBoardAtGameFrame.revalidate();
        gameBoardAtGameFrame.repaint();

        gameBoardAtGameFrame.setLayout(new GridLayout(slots[0].length, slots.length ,2,2));
        for(int i = 0; i < slots[0].length; i++){
            for(int j =0; j < slots.length; j++){
                JPanel slot = new JPanel();
                slot.setBackground(Color.WHITE);
                slots[j][i] = slot;
                if(gameList.get(g).GameBoardCoordinates[j][i] == 1)
                {
                    slots[j][i].setBackground(Color.PINK);
                }
                else if(gameList.get(g).GameBoardCoordinates[j][i] == 2)
                {
                    slots[j][i].setBackground(Color.GREEN);
                }
                JLabel slotLabel = new JLabel(j + "," +i);
                slotLabel.setForeground(Color.lightGray);
                slot.add(slotLabel);
                gameBoardAtGameFrame.add(slot);
            }
        }

        midPanelAtGameFrame.add(gameBoardAtGameFrame,BorderLayout.CENTER);
        gameFrame.add(midPanelAtGameFrame);
        gameFrame.setVisible(true);
        System.out.println("finish gameFrame");
    }

    // updates the game GUI for the server
    private void UpdateGame()
    {
        int g = getGameFromId(watchingGame); // index for the gameList
        if(g ==-1 || watchingGame == -1)
        {
            watchingGame = -1;
            return;
        }
        for(int i = 0; i < slots[0].length; i++){
            for(int j =0; j < slots.length; j++){
                if(gameList.get(g).GameBoardCoordinates[j][i] == 1)
                {
                    slots[j][i].setBackground(Color.RED);
                }
                else if(gameList.get(g).GameBoardCoordinates[j][i] == 2)
                {
                    slots[j][i].setBackground(Color.BLUE);
                }
            }
        }


    }

    private int getGameFromId(int _gameId)
    {
        for(int i = 0; i<gameList.size(); i++)
        {
            if(gameList.get(i).gameId == _gameId)
            {
                return i;
            }
        }
        return -1;
    }
}